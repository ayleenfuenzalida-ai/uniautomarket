import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import type { 
  Usuario, 
  Mensaje, 
  Chat, 
  ChatMensaje, 
  Cotizacion, 
  Notificacion,
  Resena,
  LoginCredentials, 
  RegisterData 
} from '@/types/auth';

interface AuthContextType {
  usuario: Usuario | null;
  mensajes: Mensaje[];
  chats: Chat[];
  chatMensajes: ChatMensaje[];
  cotizaciones: Cotizacion[];
  notificaciones: Notificacion[];
  resenas: Resena[];
  login: (credentials: LoginCredentials) => Promise<boolean>;
  register: (data: RegisterData) => Promise<boolean>;
  logout: () => void;
  // Favoritos
  agregarFavorito: (negocioId: string) => void;
  eliminarFavorito: (negocioId: string) => void;
  esFavorito: (negocioId: string) => boolean;
  getFavoritos: () => string[];
  // Mensajes
  enviarMensaje: (mensaje: Omit<Mensaje, 'id' | 'fecha' | 'leido'>) => void;
  marcarMensajeLeido: (mensajeId: string) => void;
  responderMensaje: (mensajeId: string, respuesta: string) => void;
  getMensajesRecibidos: (negocioId: string) => Mensaje[];
  getMensajesEnviados: (usuarioId: string) => Mensaje[];
  getMensajesNoLeidos: (negocioId: string) => number;
  // Chat
  crearChat: (clienteId: string, clienteNombre: string, negocioId: string, negocioNombre: string) => string;
  enviarChatMensaje: (chatId: string, contenido: string) => void;
  getChatMensajes: (chatId: string) => ChatMensaje[];
  getChatsPorUsuario: (usuarioId: string, tipo: 'cliente' | 'negocio') => Chat[];
  marcarChatMensajesLeidos: (chatId: string, usuarioId: string) => void;
  getChatNoLeidos: (usuarioId: string, tipo: 'cliente' | 'negocio') => number;
  // Cotizaciones
  crearCotizacion: (cotizacion: Omit<Cotizacion, 'id' | 'fechaSolicitud' | 'estado'>) => void;
  responderCotizacion: (cotizacionId: string, precio: number, respuesta: string) => void;
  getCotizacionesPorNegocio: (negocioId: string) => Cotizacion[];
  getCotizacionesPorCliente: (clienteId: string) => Cotizacion[];
  getCotizacionesPendientes: (negocioId: string) => number;
  // Notificaciones
  crearNotificacion: (notificacion: Omit<Notificacion, 'id' | 'fecha' | 'leida'>) => void;
  marcarNotificacionLeida: (notificacionId: string) => void;
  getNotificacionesPorUsuario: (usuarioId: string) => Notificacion[];
  getNotificacionesNoLeidas: (usuarioId: string) => number;
  // Resenas
  crearResena: (resena: Omit<Resena, 'id' | 'fecha'>) => void;
  responderResena: (resenaId: string, respuesta: string) => void;
  getResenasPorNegocio: (negocioId: string) => Resena[];
  getCalificacionPromedio: (negocioId: string) => number;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Usuarios de ejemplo - INCLUYE CUENTA ADMIN
const USUARIOS_EJEMPLO: (Usuario & { password: string })[] = [
  {
    id: 'admin-1',
    nombre: 'Administrador',
    email: 'admin@universalautomarket.com',
    telefono: '+56 2 2345 6789',
    tipo: 'cliente',
    fechaRegistro: '2024-01-01',
    password: 'admin123',
    favoritos: []
  },
  {
    id: 'user-1',
    nombre: 'Juan Pérez',
    email: 'juan@email.com',
    telefono: '+56 9 1234 5678',
    tipo: 'cliente',
    fechaRegistro: '2024-01-15',
    password: '123456',
    favoritos: ['desarmaduria-el-pitazo', 'taller-mecanica-express']
  },
  {
    id: 'user-2',
    nombre: 'María González',
    email: 'maria@email.com',
    telefono: '+56 9 8765 4321',
    tipo: 'cliente',
    fechaRegistro: '2024-02-20',
    password: '123456',
    favoritos: []
  },
  {
    id: 'owner-pitazo',
    nombre: 'Carlos Sánchez',
    email: 'carlos@elpitazo.cl',
    telefono: '+56 9 1234 5678',
    tipo: 'negocio',
    negocioId: 'desarmaduria-el-pitazo',
    fechaRegistro: '2024-01-01',
    password: '123456'
  },
  {
    id: 'owner-express',
    nombre: 'Pedro Méndez',
    email: 'pedro@mecanicaexpress.cl',
    telefono: '+56 9 3456 7890',
    tipo: 'negocio',
    negocioId: 'taller-mecanica-express',
    fechaRegistro: '2024-01-01',
    password: '123456'
  },
  {
    id: 'owner-autotools',
    nombre: 'Ana Rodríguez',
    email: 'ana@autotools.cl',
    telefono: '+56 9 6789 0123',
    tipo: 'negocio',
    negocioId: 'herramientas-auto-tools',
    fechaRegistro: '2024-01-01',
    password: '123456'
  },
  {
    id: 'owner-autopartes',
    nombre: 'Luis Torres',
    email: 'luis@autopartes.cl',
    telefono: '+56 9 8901 2345',
    tipo: 'negocio',
    negocioId: 'repuestos-auto-partes',
    fechaRegistro: '2024-01-01',
    password: '123456'
  },
  {
    id: 'owner-gruas',
    nombre: 'Roberto Díaz',
    email: 'roberto@gruasrapidas.cl',
    telefono: '+56 9 1111 2222',
    tipo: 'negocio',
    negocioId: 'gruas-rapidas-24h',
    fechaRegistro: '2024-01-01',
    password: '123456'
  },
  {
    id: 'owner-pintura',
    nombre: 'Diego Martínez',
    email: 'diego@carroceriapro.cl',
    telefono: '+56 9 5555 6666',
    tipo: 'negocio',
    negocioId: 'pintura-carroceria-pro',
    fechaRegistro: '2024-01-01',
    password: '123456'
  }
];

// Datos de ejemplo
const MENSAJES_EJEMPLO: Mensaje[] = [];
const CHATS_EJEMPLO: Chat[] = [];
const CHAT_MENSAJES_EJEMPLO: ChatMensaje[] = [];
const COTIZACIONES_EJEMPLO: Cotizacion[] = [];
const NOTIFICACIONES_EJEMPLO: Notificacion[] = [];

// Reseñas de ejemplo
const RESENAS_EJEMPLO: Resena[] = [
  {
    id: 'res-1',
    negocioId: 'desarmaduria-el-pitazo',
    clienteId: 'user-1',
    clienteNombre: 'Juan Pérez',
    calificacion: 5,
    comentario: 'Excelente servicio, encontré el repuesto que necesitaba a buen precio. Muy recomendado.',
    fecha: '2024-02-10T10:00:00',
    respuestaNegocio: 'Gracias Juan por tu preferencia! Quedamos atentos para futuras consultas.',
    fechaRespuesta: '2024-02-10T14:00:00'
  },
  {
    id: 'res-2',
    negocioId: 'desarmaduria-el-pitazo',
    clienteId: 'user-2',
    clienteNombre: 'María González',
    calificacion: 4,
    comentario: 'Buena atención, aunque el tiempo de entrega fue un poco largo.',
    fecha: '2024-02-12T16:30:00'
  },
  {
    id: 'res-3',
    negocioId: 'taller-mecanica-express',
    clienteId: 'user-1',
    clienteNombre: 'Juan Pérez',
    calificacion: 5,
    comentario: 'Servicio rápido y profesional. Mi auto quedó perfecto.',
    fecha: '2024-02-08T09:00:00',
    respuestaNegocio: 'Agradecemos tu visita Juan! Trabajamos para brindar el mejor servicio.',
    fechaRespuesta: '2024-02-08T11:00:00'
  }
];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [usuario, setUsuario] = useState<Usuario | null>(null);
  const [mensajes, setMensajes] = useState<Mensaje[]>(MENSAJES_EJEMPLO);
  const [chats, setChats] = useState<Chat[]>(CHATS_EJEMPLO);
  const [chatMensajes, setChatMensajes] = useState<ChatMensaje[]>(CHAT_MENSAJES_EJEMPLO);
  const [cotizaciones, setCotizaciones] = useState<Cotizacion[]>(COTIZACIONES_EJEMPLO);
  const [notificaciones, setNotificaciones] = useState<Notificacion[]>(NOTIFICACIONES_EJEMPLO);
  const [resenas, setResenas] = useState<Resena[]>(RESENAS_EJEMPLO);

  // Cargar desde localStorage
  useEffect(() => {
    const savedUser = localStorage.getItem('universal_automarket_user');
    if (savedUser) setUsuario(JSON.parse(savedUser));
    
    const keys = ['mensajes', 'chats', 'chat_mensajes', 'cotizaciones', 'notificaciones', 'resenas'];
    keys.forEach(key => {
      const saved = localStorage.getItem(`universal_automarket_${key}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        switch(key) {
          case 'mensajes': setMensajes(parsed); break;
          case 'chats': setChats(parsed); break;
          case 'chat_mensajes': setChatMensajes(parsed); break;
          case 'cotizaciones': setCotizaciones(parsed); break;
          case 'notificaciones': setNotificaciones(parsed); break;
          case 'resenas': setResenas(parsed); break;
        }
      }
    });
  }, []);

  // Guardar en localStorage
  useEffect(() => { localStorage.setItem('universal_automarket_mensajes', JSON.stringify(mensajes)); }, [mensajes]);
  useEffect(() => { localStorage.setItem('universal_automarket_chats', JSON.stringify(chats)); }, [chats]);
  useEffect(() => { localStorage.setItem('universal_automarket_chat_mensajes', JSON.stringify(chatMensajes)); }, [chatMensajes]);
  useEffect(() => { localStorage.setItem('universal_automarket_cotizaciones', JSON.stringify(cotizaciones)); }, [cotizaciones]);
  useEffect(() => { localStorage.setItem('universal_automarket_notificaciones', JSON.stringify(notificaciones)); }, [notificaciones]);
  useEffect(() => { localStorage.setItem('universal_automarket_resenas', JSON.stringify(resenas)); }, [resenas]);

  const login = async (credentials: LoginCredentials): Promise<boolean> => {
    const foundUser = USUARIOS_EJEMPLO.find(
      u => u.email === credentials.email && u.password === credentials.password
    );
    
    if (foundUser) {
      const { password, ...userWithoutPassword } = foundUser;
      setUsuario(userWithoutPassword);
      localStorage.setItem('universal_automarket_user', JSON.stringify(userWithoutPassword));
      return true;
    }
    return false;
  };

  const register = async (data: RegisterData): Promise<boolean> => {
    const existingUser = USUARIOS_EJEMPLO.find(u => u.email === data.email);
    if (existingUser) return false;

    const newUser: Usuario = {
      id: `user-${Date.now()}`,
      nombre: data.nombre,
      email: data.email,
      telefono: data.telefono,
      tipo: data.tipo,
      negocioId: data.negocioId,
      fechaRegistro: new Date().toISOString().split('T')[0],
      favoritos: []
    };

    USUARIOS_EJEMPLO.push({ ...newUser, password: data.password });
    setUsuario(newUser);
    localStorage.setItem('universal_automarket_user', JSON.stringify(newUser));
    return true;
  };

  const logout = () => {
    setUsuario(null);
    localStorage.removeItem('universal_automarket_user');
  };

  // Favoritos
  const agregarFavorito = useCallback((negocioId: string) => {
    if (!usuario) return;
    const updatedFavoritos = [...(usuario.favoritos || []), negocioId];
    const updatedUser = { ...usuario, favoritos: updatedFavoritos };
    setUsuario(updatedUser);
    localStorage.setItem('universal_automarket_user', JSON.stringify(updatedUser));
    
    // Actualizar en la lista de usuarios
    const userIndex = USUARIOS_EJEMPLO.findIndex(u => u.id === usuario.id);
    if (userIndex !== -1) {
      USUARIOS_EJEMPLO[userIndex].favoritos = updatedFavoritos;
    }
  }, [usuario]);

  const eliminarFavorito = useCallback((negocioId: string) => {
    if (!usuario) return;
    const updatedFavoritos = (usuario.favoritos || []).filter(id => id !== negocioId);
    const updatedUser = { ...usuario, favoritos: updatedFavoritos };
    setUsuario(updatedUser);
    localStorage.setItem('universal_automarket_user', JSON.stringify(updatedUser));
    
    const userIndex = USUARIOS_EJEMPLO.findIndex(u => u.id === usuario.id);
    if (userIndex !== -1) {
      USUARIOS_EJEMPLO[userIndex].favoritos = updatedFavoritos;
    }
  }, [usuario]);

  const esFavorito = useCallback((negocioId: string): boolean => {
    return usuario?.favoritos?.includes(negocioId) || false;
  }, [usuario]);

  const getFavoritos = useCallback((): string[] => {
    return usuario?.favoritos || [];
  }, [usuario]);

  // Mensajes
  const enviarMensaje = useCallback((mensajeData: Omit<Mensaje, 'id' | 'fecha' | 'leido'>) => {
    const newMessage: Mensaje = {
      ...mensajeData,
      id: `msg-${Date.now()}`,
      fecha: new Date().toISOString(),
      leido: false
    };
    setMensajes(prev => [newMessage, ...prev]);
    
    crearNotificacion({
      usuarioId: mensajeData.destinatarioId,
      tipo: 'mensaje',
      titulo: 'Nuevo mensaje recibido',
      contenido: `${mensajeData.remitenteNombre} te ha enviado un mensaje: ${mensajeData.asunto}`,
      link: '/micuenta'
    });
  }, []);

  const marcarMensajeLeido = useCallback((mensajeId: string) => {
    setMensajes(prev => prev.map(msg => msg.id === mensajeId ? { ...msg, leido: true } : msg));
  }, []);

  const responderMensaje = useCallback((mensajeId: string, respuesta: string) => {
    setMensajes(prev => prev.map(msg => msg.id === mensajeId ? { ...msg, respuesta, leido: true } : msg));
  }, []);

  const getMensajesRecibidos = useCallback((negocioId: string): Mensaje[] => {
    return mensajes.filter(msg => msg.destinatarioNegocioId === negocioId);
  }, [mensajes]);

  const getMensajesEnviados = useCallback((usuarioId: string): Mensaje[] => {
    return mensajes.filter(msg => msg.remitenteId === usuarioId);
  }, [mensajes]);

  const getMensajesNoLeidos = useCallback((negocioId: string): number => {
    return mensajes.filter(msg => msg.destinatarioNegocioId === negocioId && !msg.leido).length;
  }, [mensajes]);

  // Chat
  const crearChat = useCallback((clienteId: string, clienteNombre: string, negocioId: string, negocioNombre: string): string => {
    const existingChat = chats.find(c => c.clienteId === clienteId && c.negocioId === negocioId);
    if (existingChat) return existingChat.id;

    const newChat: Chat = {
      id: `chat-${Date.now()}`,
      clienteId,
      clienteNombre,
      negocioId,
      negocioNombre,
      ultimoMensaje: '',
      fechaUltimoMensaje: new Date().toISOString(),
      mensajesNoLeidos: 0
    };
    setChats(prev => [newChat, ...prev]);
    return newChat.id;
  }, [chats]);

  const enviarChatMensaje = useCallback((chatId: string, contenido: string) => {
    if (!usuario) return;

    const newMessage: ChatMensaje = {
      id: `cm-${Date.now()}`,
      chatId,
      remitenteId: usuario.id,
      remitenteNombre: usuario.nombre,
      remitenteTipo: usuario.tipo,
      contenido,
      fecha: new Date().toISOString(),
      leido: false
    };

    setChatMensajes(prev => [...prev, newMessage]);

    setChats(prev => prev.map(chat => 
      chat.id === chatId ? {
        ...chat,
        ultimoMensaje: contenido,
        fechaUltimoMensaje: newMessage.fecha,
        mensajesNoLeidos: chat.mensajesNoLeidos + 1
      } : chat
    ));

    const chat = chats.find(c => c.id === chatId);
    if (chat) {
      const destinatarioId = usuario.tipo === 'cliente' ? chat.negocioId : chat.clienteId;
      crearNotificacion({
        usuarioId: destinatarioId,
        tipo: 'chat',
        titulo: 'Nuevo mensaje de chat',
        contenido: `${usuario.nombre}: ${contenido.substring(0, 50)}${contenido.length > 50 ? '...' : ''}`,
        link: '/micuenta'
      });
    }
  }, [usuario, chats]);

  const getChatMensajes = useCallback((chatId: string): ChatMensaje[] => {
    return chatMensajes.filter(msg => msg.chatId === chatId).sort((a, b) => 
      new Date(a.fecha).getTime() - new Date(b.fecha).getTime()
    );
  }, [chatMensajes]);

  const getChatsPorUsuario = useCallback((usuarioId: string, tipo: 'cliente' | 'negocio'): Chat[] => {
    return chats.filter(chat => 
      tipo === 'cliente' ? chat.clienteId === usuarioId : chat.negocioId === usuarioId
    ).sort((a, b) => 
      new Date(b.fechaUltimoMensaje).getTime() - new Date(a.fechaUltimoMensaje).getTime()
    );
  }, [chats]);

  const marcarChatMensajesLeidos = useCallback((chatId: string, usuarioId: string) => {
    setChatMensajes(prev => prev.map(msg => 
      msg.chatId === chatId && msg.remitenteId !== usuarioId ? { ...msg, leido: true } : msg
    ));
    setChats(prev => prev.map(chat => chat.id === chatId ? { ...chat, mensajesNoLeidos: 0 } : chat));
  }, []);

  const getChatNoLeidos = useCallback((usuarioId: string, tipo: 'cliente' | 'negocio'): number => {
    return chats
      .filter(chat => tipo === 'cliente' ? chat.clienteId === usuarioId : chat.negocioId === usuarioId)
      .reduce((total, chat) => total + chat.mensajesNoLeidos, 0);
  }, [chats]);

  // Cotizaciones
  const crearCotizacion = useCallback((cotizacionData: Omit<Cotizacion, 'id' | 'fechaSolicitud' | 'estado'>) => {
    const newCotizacion: Cotizacion = {
      ...cotizacionData,
      id: `cot-${Date.now()}`,
      fechaSolicitud: new Date().toISOString(),
      estado: 'pendiente'
    };
    setCotizaciones(prev => [newCotizacion, ...prev]);
    
    const negocioOwner = USUARIOS_EJEMPLO.find(u => u.negocioId === cotizacionData.negocioId);
    if (negocioOwner) {
      crearNotificacion({
        usuarioId: negocioOwner.id,
        tipo: 'cotizacion',
        titulo: 'Nueva cotización solicitada',
        contenido: `${cotizacionData.clienteNombre} solicita cotización para ${cotizacionData.itemNombre}`,
        link: '/micuenta'
      });
    }
  }, []);

  const responderCotizacion = useCallback((cotizacionId: string, precio: number, respuesta: string) => {
    setCotizaciones(prev => prev.map(cot => 
      cot.id === cotizacionId ? { 
        ...cot, 
        estado: 'respondida', 
        precioCotizado: precio, 
        respuesta,
        fechaRespuesta: new Date().toISOString()
      } : cot
    ));

    const cotizacion = cotizaciones.find(c => c.id === cotizacionId);
    if (cotizacion) {
      crearNotificacion({
        usuarioId: cotizacion.clienteId,
        tipo: 'cotizacion',
        titulo: 'Cotización respondida',
        contenido: `${cotizacion.negocioNombre} respondió tu cotización para ${cotizacion.itemNombre}`,
        link: '/micuenta'
      });
    }
  }, [cotizaciones]);

  const getCotizacionesPorNegocio = useCallback((negocioId: string): Cotizacion[] => {
    return cotizaciones.filter(cot => cot.negocioId === negocioId);
  }, [cotizaciones]);

  const getCotizacionesPorCliente = useCallback((clienteId: string): Cotizacion[] => {
    return cotizaciones.filter(cot => cot.clienteId === clienteId);
  }, [cotizaciones]);

  const getCotizacionesPendientes = useCallback((negocioId: string): number => {
    return cotizaciones.filter(cot => cot.negocioId === negocioId && cot.estado === 'pendiente').length;
  }, [cotizaciones]);

  // Notificaciones
  const crearNotificacion = useCallback((notificacionData: Omit<Notificacion, 'id' | 'fecha' | 'leida'>) => {
    const newNotificacion: Notificacion = {
      ...notificacionData,
      id: `not-${Date.now()}`,
      fecha: new Date().toISOString(),
      leida: false
    };
    setNotificaciones(prev => [newNotificacion, ...prev]);
  }, []);

  const marcarNotificacionLeida = useCallback((notificacionId: string) => {
    setNotificaciones(prev => prev.map(not => not.id === notificacionId ? { ...not, leida: true } : not));
  }, []);

  const getNotificacionesPorUsuario = useCallback((usuarioId: string): Notificacion[] => {
    return notificaciones.filter(not => not.usuarioId === usuarioId);
  }, [notificaciones]);

  const getNotificacionesNoLeidas = useCallback((usuarioId: string): number => {
    return notificaciones.filter(not => not.usuarioId === usuarioId && !not.leida).length;
  }, [notificaciones]);

  // Resenas
  const crearResena = useCallback((resenaData: Omit<Resena, 'id' | 'fecha'>) => {
    const newResena: Resena = {
      ...resenaData,
      id: `res-${Date.now()}`,
      fecha: new Date().toISOString()
    };
    setResenas(prev => [newResena, ...prev]);
    
    const negocioOwner = USUARIOS_EJEMPLO.find(u => u.negocioId === resenaData.negocioId);
    if (negocioOwner) {
      crearNotificacion({
        usuarioId: negocioOwner.id,
        tipo: 'sistema',
        titulo: 'Nueva reseña recibida',
        contenido: `${resenaData.clienteNombre} te calificó con ${resenaData.calificacion} estrellas`,
        link: '/micuenta'
      });
    }
  }, []);

  const responderResena = useCallback((resenaId: string, respuesta: string) => {
    setResenas(prev => prev.map(res => 
      res.id === resenaId ? { ...res, respuestaNegocio: respuesta, fechaRespuesta: new Date().toISOString() } : res
    ));
  }, []);

  const getResenasPorNegocio = useCallback((negocioId: string): Resena[] => {
    return resenas.filter(res => res.negocioId === negocioId).sort((a, b) => 
      new Date(b.fecha).getTime() - new Date(a.fecha).getTime()
    );
  }, [resenas]);

  const getCalificacionPromedio = useCallback((negocioId: string): number => {
    const resenasNegocio = resenas.filter(res => res.negocioId === negocioId);
    if (resenasNegocio.length === 0) return 0;
    return Math.round((resenasNegocio.reduce((sum, r) => sum + r.calificacion, 0) / resenasNegocio.length) * 10) / 10;
  }, [resenas]);

  return (
    <AuthContext.Provider value={{
      usuario,
      mensajes,
      chats,
      chatMensajes,
      cotizaciones,
      notificaciones,
      resenas,
      login,
      register,
      logout,
      // Favoritos
      agregarFavorito,
      eliminarFavorito,
      esFavorito,
      getFavoritos,
      // Mensajes
      enviarMensaje,
      marcarMensajeLeido,
      responderMensaje,
      getMensajesRecibidos,
      getMensajesEnviados,
      getMensajesNoLeidos,
      // Chat
      crearChat,
      enviarChatMensaje,
      getChatMensajes,
      getChatsPorUsuario,
      marcarChatMensajesLeidos,
      getChatNoLeidos,
      // Cotizaciones
      crearCotizacion,
      responderCotizacion,
      getCotizacionesPorNegocio,
      getCotizacionesPorCliente,
      getCotizacionesPendientes,
      // Notificaciones
      crearNotificacion,
      marcarNotificacionLeida,
      getNotificacionesPorUsuario,
      getNotificacionesNoLeidas,
      // Resenas
      crearResena,
      responderResena,
      getResenasPorNegocio,
      getCalificacionPromedio
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth debe usarse dentro de AuthProvider');
  }
  return context;
}
