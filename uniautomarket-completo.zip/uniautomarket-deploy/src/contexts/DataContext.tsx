import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { Categoria, Negocio, Producto, Servicio } from '@/types';
import { categorias as initialCategorias } from '@/data/marketplace';

interface DataContextType {
  categorias: Categoria[];
  updateCategoria: (categoria: Categoria) => void;
  deleteCategoria: (id: string) => void;
  addCategoria: (categoria: Categoria) => void;
  updateNegocio: (categoriaId: string, negocio: Negocio) => void;
  deleteNegocio: (categoriaId: string, negocioId: string) => void;
  addNegocio: (categoriaId: string, negocio: Negocio) => void;
  updateProducto: (categoriaId: string, negocioId: string, producto: Producto) => void;
  deleteProducto: (categoriaId: string, negocioId: string, productoId: string) => void;
  addProducto: (categoriaId: string, negocioId: string, producto: Producto) => void;
  updateServicio: (categoriaId: string, negocioId: string, servicio: Servicio) => void;
  deleteServicio: (categoriaId: string, negocioId: string, servicioId: string) => void;
  addServicio: (categoriaId: string, negocioId: string, servicio: Servicio) => void;
  getNegocioById: (id: string) => Negocio | undefined;
  getCategoriaById: (id: string) => Categoria | undefined;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  const [categorias, setCategorias] = useState<Categoria[]>(initialCategorias);

  const updateCategoria = useCallback((categoria: Categoria) => {
    setCategorias(prev => 
      prev.map(c => c.id === categoria.id ? categoria : c)
    );
  }, []);

  const deleteCategoria = useCallback((id: string) => {
    setCategorias(prev => prev.filter(c => c.id !== id));
  }, []);

  const addCategoria = useCallback((categoria: Categoria) => {
    setCategorias(prev => [...prev, categoria]);
  }, []);

  const updateNegocio = useCallback((categoriaId: string, negocio: Negocio) => {
    setCategorias(prev => 
      prev.map(cat => {
        if (cat.id === categoriaId) {
          return {
            ...cat,
            negocios: cat.negocios.map(n => n.id === negocio.id ? negocio : n)
          };
        }
        return cat;
      })
    );
  }, []);

  const deleteNegocio = useCallback((categoriaId: string, negocioId: string) => {
    setCategorias(prev => 
      prev.map(cat => {
        if (cat.id === categoriaId) {
          return {
            ...cat,
            negocios: cat.negocios.filter(n => n.id !== negocioId)
          };
        }
        return cat;
      })
    );
  }, []);

  const addNegocio = useCallback((categoriaId: string, negocio: Negocio) => {
    setCategorias(prev => 
      prev.map(cat => {
        if (cat.id === categoriaId) {
          return {
            ...cat,
            negocios: [...cat.negocios, negocio]
          };
        }
        return cat;
      })
    );
  }, []);

  const updateProducto = useCallback((categoriaId: string, negocioId: string, producto: Producto) => {
    setCategorias(prev => 
      prev.map(cat => {
        if (cat.id === categoriaId) {
          return {
            ...cat,
            negocios: cat.negocios.map(n => {
              if (n.id === negocioId && n.productos) {
                return {
                  ...n,
                  productos: n.productos.map(p => p.id === producto.id ? producto : p)
                };
              }
              return n;
            })
          };
        }
        return cat;
      })
    );
  }, []);

  const deleteProducto = useCallback((categoriaId: string, negocioId: string, productoId: string) => {
    setCategorias(prev => 
      prev.map(cat => {
        if (cat.id === categoriaId) {
          return {
            ...cat,
            negocios: cat.negocios.map(n => {
              if (n.id === negocioId && n.productos) {
                return {
                  ...n,
                  productos: n.productos.filter(p => p.id !== productoId)
                };
              }
              return n;
            })
          };
        }
        return cat;
      })
    );
  }, []);

  const addProducto = useCallback((categoriaId: string, negocioId: string, producto: Producto) => {
    setCategorias(prev => 
      prev.map(cat => {
        if (cat.id === categoriaId) {
          return {
            ...cat,
            negocios: cat.negocios.map(n => {
              if (n.id === negocioId) {
                return {
                  ...n,
                  productos: [...(n.productos || []), producto]
                };
              }
              return n;
            })
          };
        }
        return cat;
      })
    );
  }, []);

  const updateServicio = useCallback((categoriaId: string, negocioId: string, servicio: Servicio) => {
    setCategorias(prev => 
      prev.map(cat => {
        if (cat.id === categoriaId) {
          return {
            ...cat,
            negocios: cat.negocios.map(n => {
              if (n.id === negocioId && n.servicios) {
                return {
                  ...n,
                  servicios: n.servicios.map(s => s.id === servicio.id ? servicio : s)
                };
              }
              return n;
            })
          };
        }
        return cat;
      })
    );
  }, []);

  const deleteServicio = useCallback((categoriaId: string, negocioId: string, servicioId: string) => {
    setCategorias(prev => 
      prev.map(cat => {
        if (cat.id === categoriaId) {
          return {
            ...cat,
            negocios: cat.negocios.map(n => {
              if (n.id === negocioId && n.servicios) {
                return {
                  ...n,
                  servicios: n.servicios.filter(s => s.id !== servicioId)
                };
              }
              return n;
            })
          };
        }
        return cat;
      })
    );
  }, []);

  const addServicio = useCallback((categoriaId: string, negocioId: string, servicio: Servicio) => {
    setCategorias(prev => 
      prev.map(cat => {
        if (cat.id === categoriaId) {
          return {
            ...cat,
            negocios: cat.negocios.map(n => {
              if (n.id === negocioId) {
                return {
                  ...n,
                  servicios: [...(n.servicios || []), servicio]
                };
              }
              return n;
            })
          };
        }
        return cat;
      })
    );
  }, []);

  const getNegocioById = useCallback((id: string): Negocio | undefined => {
    for (const categoria of categorias) {
      const negocio = categoria.negocios.find(n => n.id === id);
      if (negocio) return negocio;
    }
    return undefined;
  }, [categorias]);

  const getCategoriaById = useCallback((id: string): Categoria | undefined => {
    return categorias.find(c => c.id === id);
  }, [categorias]);

  return (
    <DataContext.Provider value={{
      categorias,
      updateCategoria,
      deleteCategoria,
      addCategoria,
      updateNegocio,
      deleteNegocio,
      addNegocio,
      updateProducto,
      deleteProducto,
      addProducto,
      updateServicio,
      deleteServicio,
      addServicio,
      getNegocioById,
      getCategoriaById,
    }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}
