export interface Producto {
  id: string;
  nombre: string;
  descripcion: string;
  precio: number;
  imagen: string;
  disponible: boolean;
}

export interface Servicio {
  id: string;
  nombre: string;
  descripcion: string;
  precioDesde: number;
  imagen: string;
}

export interface Negocio {
  id: string;
  nombre: string;
  categoriaId: string;
  imagen: string;
  direccion: string;
  telefono: string;
  email: string;
  horario: string;
  descripcion: string;
  rating: number;
  productos?: Producto[];
  servicios?: Servicio[];
}

export interface Categoria {
  id: string;
  nombre: string;
  descripcion: string;
  imagen: string;
  icono: string;
  color: string;
  negocios: Negocio[];
}
