import { ChevronRight } from 'lucide-react';
import type { Categoria } from '@/types';

interface CategoriesSectionProps {
  categorias: Categoria[];
  onCategoriaClick: (categoriaId: string) => void;
}

export function CategoriesSection({ categorias, onCategoriaClick }: CategoriesSectionProps) {
  return (
    <section id="categorias" className="py-20 bg-[#0a0a0a] relative">
      {/* Background effect */}
      <div className="absolute inset-0 bg-gradient-to-b from-red-900/10 via-transparent to-transparent pointer-events-none" />
      
      <div className="container mx-auto px-4 relative">
        <div className="text-center mb-12">
          <p className="text-red-500 text-sm font-medium tracking-widest uppercase mb-4">Categorías</p>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Explora por <span className="text-red-500">Categoría</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Encuentra exactamente lo que necesitas navegando por nuestras categorías especializadas
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categorias.map((categoria) => (
            <button
              key={categoria.id}
              onClick={() => onCategoriaClick(categoria.id)}
              className="group relative overflow-hidden rounded-2xl border border-gray-800 hover:border-red-500/50 transition-all text-left h-[280px]"
            >
              {/* Background Image */}
              <div className="absolute inset-0">
                <img
                  src={categoria.imagen}
                  alt={categoria.nombre}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                {/* Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent" />
              </div>

              {/* Icon */}
              <div 
                className="absolute top-4 left-4 w-12 h-12 rounded-xl flex items-center justify-center transition-transform duration-300 group-hover:scale-110"
                style={{ backgroundColor: categoria.color }}
              >
                <span className="text-white text-xl">{categoria.icono}</span>
              </div>

              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="text-xl font-bold text-white mb-2 group-hover:text-red-400 transition-colors">
                  {categoria.nombre}
                </h3>
                <p className="text-gray-400 text-sm mb-3 line-clamp-2">
                  {categoria.descripcion}
                </p>

                <div className="flex items-center justify-between">
                  <span className="text-gray-500 text-sm">
                    {categoria.negocios.length} negocios
                  </span>
                  <ChevronRight className="w-5 h-5 text-gray-600 group-hover:text-red-500 group-hover:translate-x-1 transition-all" />
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
