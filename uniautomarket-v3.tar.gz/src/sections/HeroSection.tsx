import { useState, useEffect } from 'react';
import { ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const heroCars = [
  '/images/hero/car1.jpg',
  '/images/hero/car2.jpg',
  '/images/hero/car3.jpg',
  '/images/hero/car4.jpg',
];

export function HeroSection() {
  const [currentSlide, setCurrentSlide] = useState(0);

  // Auto-rotate carousel cada 6 segundos
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroCars.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Carousel - Sin controles manuales */}
      <div className="absolute inset-0">
        {heroCars.map((car, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <img
              src={car}
              alt="Vehículo"
              className="w-full h-full object-cover object-center"
            />
          </div>
        ))}
        {/* Dark overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/50 to-[#0a0a0a]/30" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a]/60 via-transparent to-[#0a0a0a]/60" />
      </div>

      {/* Slide Indicators (solo dots) */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex gap-2">
        {heroCars.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-2 h-2 rounded-full transition-all ${
              index === currentSlide ? 'bg-red-500 w-6' : 'bg-white/40 hover:bg-white/60'
            }`}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-black/40 border border-red-500/30 rounded-full mb-8 backdrop-blur-sm">
            <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
            <span className="text-red-400 text-sm font-medium tracking-wide">MARKETPLACE AUTOMOTRIZ #1 DE CHILE</span>
          </div>

          {/* Title */}
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-4 leading-tight">
            Encuentra todo para tu
          </h1>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-red-500 mb-8 leading-tight">
            vehículo
          </h1>

          <p className="text-lg md:text-xl text-gray-300 mb-10 max-w-2xl mx-auto">
            Repuestos, talleres, herramientas y servicios automotrices en un solo lugar. Conectamos dueños de vehículos con los mejores proveedores.
          </p>

          {/* Buttons */}
          <div className="flex flex-wrap justify-center gap-4 mb-16">
            <Button 
              onClick={() => document.getElementById('categorias')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-red-600 hover:bg-red-700 text-white px-8 py-6 text-lg rounded-lg"
            >
              Explorar Categorías <ChevronRight className="w-5 h-5 ml-2" />
            </Button>
            <Button 
              variant="outline"
              className="border-gray-600 text-white hover:bg-white/10 px-8 py-6 text-lg rounded-lg"
            >
              Vender Productos
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="bg-black/40 backdrop-blur-sm rounded-xl p-6 border border-gray-800">
              <div className="text-4xl md:text-5xl font-bold text-white mb-1">500+</div>
              <div className="text-gray-400 text-sm uppercase tracking-wide">Negocios</div>
            </div>
            <div className="bg-black/40 backdrop-blur-sm rounded-xl p-6 border border-gray-800">
              <div className="text-4xl md:text-5xl font-bold text-white mb-1">50K+</div>
              <div className="text-gray-400 text-sm uppercase tracking-wide">Productos</div>
            </div>
            <div className="bg-black/40 backdrop-blur-sm rounded-xl p-6 border border-gray-800">
              <div className="text-4xl md:text-5xl font-bold text-white mb-1">100K+</div>
              <div className="text-gray-400 text-sm uppercase tracking-wide">Usuarios</div>
            </div>
            <div className="bg-black/40 backdrop-blur-sm rounded-xl p-6 border border-gray-800">
              <div className="text-4xl md:text-5xl font-bold text-white mb-1">4.8</div>
              <div className="text-gray-400 text-sm uppercase tracking-wide">Rating</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
