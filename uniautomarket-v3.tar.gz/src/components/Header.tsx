import { useState, useEffect } from 'react';
import { Search, Menu, X, User, LogOut, Shield, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useData } from '@/contexts/DataContext';
import { useAuth } from '@/contexts/AuthContext';
import { LoginModal } from './LoginModal';

interface HeaderProps {
  onNavigateHome: () => void;
  onSearch: (query: string) => void;
  onMiCuenta: () => void;
  onAdmin?: () => void;
  onBlog?: () => void;
}

export function Header({ onNavigateHome, onSearch, onMiCuenta, onAdmin, onBlog }: HeaderProps) {
  const [searchValue, setSearchValue] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const { usuario, logout, isSuperAdmin, isAdmin } = useAuth();
  const { categorias } = useData();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchValue.trim()) onSearch(searchValue.trim());
  };

  const handleLogout = () => {
    logout();
    onNavigateHome();
  };

  return (
    <>
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${isScrolled ? 'bg-[#0a0a0a]/90 backdrop-blur-xl border-b border-red-500/20' : 'bg-transparent'}`}>
        <div className="h-[2px] bg-gradient-to-r from-transparent via-red-500 to-transparent animate-pulse" />
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-4">
            <button onClick={onNavigateHome} className="flex items-center gap-3 group">
              <div className="relative">
                <div className="absolute inset-0 bg-red-500 blur-xl opacity-50 group-hover:opacity-80 transition-opacity" />
                <div className="relative h-12 w-12 bg-gradient-to-br from-red-500 to-red-700 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-xl">U</span>
                </div>
              </div>
              <span className="hidden md:block text-white font-bold text-xl">Universal AutoMarket</span>
            </button>

            <form onSubmit={handleSearch} className="flex-1 max-w-2xl">
              <div className="relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-red-600 to-red-800 rounded-full opacity-30 group-hover:opacity-60 transition-opacity blur" />
                <div className="relative flex items-center">
                  <Input type="text" placeholder="Buscar repuestos, talleres..." value={searchValue} onChange={(e) => setSearchValue(e.target.value)} className="w-full pl-5 pr-12 py-3 h-12 bg-[#111111] border border-gray-700 rounded-full text-white" />
                  <Button type="submit" variant="ghost" className="absolute right-1 top-1/2 -translate-y-1/2 p-2 hover:bg-red-500/20 rounded-full"><Search className="w-5 h-5 text-red-500" /></Button>
                </div>
              </div>
            </form>

            <div className="hidden lg:flex items-center gap-3">
              {onBlog && <Button variant="ghost" className="text-gray-300 hover:text-white hover:bg-red-500/20" onClick={onBlog}><BookOpen className="w-5 h-5" /></Button>}
              
              {usuario ? (
                <>
                  {(isSuperAdmin || isAdmin) && onAdmin && (
                    <Button variant="outline" className="border-amber-500/50 text-amber-400 hover:bg-amber-500/20" onClick={onAdmin}><Shield className="w-4 h-4 mr-2" />Admin</Button>
                  )}
                  <Button variant="outline" className="border-red-500/50 text-white hover:bg-red-500/20" onClick={onMiCuenta}><User className="w-4 h-4 mr-2" />{usuario.nombre.split(' ')[0]}</Button>
                  <Button variant="ghost" onClick={handleLogout} className="text-gray-400 hover:text-red-400"><LogOut className="w-5 h-5" /></Button>
                </>
              ) : (
                <Button variant="outline" className="border-red-500/50 text-white hover:bg-red-500/20" onClick={() => setIsLoginModalOpen(true)}><User className="w-4 h-4 mr-2" />Acceso</Button>
              )}
            </div>

            <Button variant="ghost" className="lg:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>{isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}</Button>
          </div>
        </div>

        <nav className="hidden lg:block border-t border-gray-800/50">
          <div className="container mx-auto px-4">
            <ul className="flex items-center gap-1 py-2 overflow-x-auto">
              {categorias.map((categoria) => (
                <li key={categoria.id}>
                  <button onClick={() => onNavigateHome()} className="px-4 py-2 text-sm font-medium text-gray-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all whitespace-nowrap">{categoria.nombre}</button>
                </li>
              ))}
            </ul>
          </div>
        </nav>

        {isMenuOpen && (
          <div className="lg:hidden bg-[#0a0a0a]/95 backdrop-blur-xl border-t border-red-500/20">
            <div className="container mx-auto px-4 py-4">
              {usuario ? (
                <div className="flex flex-col gap-3 mb-4">
                  <div className="p-4 bg-gradient-to-r from-red-900/30 to-transparent rounded-xl border border-red-500/20">
                    <p className="font-semibold text-white">{usuario.nombre}</p>
                    <p className="text-sm text-gray-400">{usuario.email}</p>
                  </div>
                  {(isSuperAdmin || isAdmin) && onAdmin && <Button variant="outline" className="border-amber-500/50 text-amber-400" onClick={() => { onAdmin(); setIsMenuOpen(false); }}><Shield className="w-4 h-4 mr-2" />Admin</Button>}
                  <Button variant="outline" className="border-red-500/50 text-white" onClick={() => { onMiCuenta(); setIsMenuOpen(false); }}><User className="w-4 h-4 mr-2" />Mi Cuenta</Button>
                  <Button variant="outline" className="text-red-400 border-red-500/30" onClick={() => { handleLogout(); setIsMenuOpen(false); }}><LogOut className="w-4 h-4 mr-2" />Cerrar Sesión</Button>
                </div>
              ) : (
                <Button variant="outline" className="w-full border-red-500/50 text-white mb-4" onClick={() => { setIsLoginModalOpen(true); setIsMenuOpen(false); }}><User className="w-4 h-4 mr-2" />Acceso</Button>
              )}
              {onBlog && <Button variant="outline" className="w-full border-amber-500/50 text-amber-400 mb-4" onClick={() => { onBlog(); setIsMenuOpen(false); }}><BookOpen className="w-4 h-4 mr-2" />Blog</Button>}
            </div>
          </div>
        )}
      </header>
      <div className="h-[100px] lg:h-[120px]" />
      <LoginModal isOpen={isLoginModalOpen} onClose={() => setIsLoginModalOpen(false)} />
    </>
  );
}
