import { ArrowLeft, Star, MapPin, Phone, Clock, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useData } from '@/contexts/DataContext';

interface CategoriaPageProps {
  categoriaId: string;
  onNegocioClick: (negocioId: string) => void;
  onBack: () => void;
}

export function CategoriaPage({ categoriaId, onNegocioClick, onBack }: CategoriaPageProps) {
  const { getCategoriaById } = useData();
  const categoria = getCategoriaById(categoriaId);

  if (!categoria) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Categoría no encontrada</h2>
        <Button onClick={onBack}>Volver al inicio</Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className={`${categoria.color} text-white`}>
        <div className="container mx-auto px-4 py-8">
          <Button 
            variant="ghost" 
            className="text-white hover:bg-white/20 mb-4 -ml-4"
            onClick={onBack}
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Volver
          </Button>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">{categoria.nombre}</h1>
          <p className="text-white/90 text-lg max-w-2xl">{categoria.descripcion}</p>
          <div className="mt-4 flex items-center gap-4">
            <Badge className="bg-white/20 text-white">
              {categoria.negocios.length} negocios
            </Badge>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-sm font-medium text-gray-700">Filtrar por:</span>
            <Button variant="outline" size="sm" className="text-sm">
              Mejor Rating
            </Button>
            <Button variant="outline" size="sm" className="text-sm">
              Más Cercano
            </Button>
            <Button variant="outline" size="sm" className="text-sm">
              Abierto Ahora
            </Button>
          </div>
        </div>
      </div>

      {/* Businesses List */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {categoria.negocios.map((negocio) => (
            <Card 
              key={negocio.id}
              className="group cursor-pointer overflow-hidden hover:shadow-xl transition-all duration-300"
              onClick={() => onNegocioClick(negocio.id)}
            >
              <div className="flex flex-col md:flex-row">
                {/* Image */}
                <div className="md:w-2/5 h-48 md:h-auto bg-gradient-to-br from-gray-200 to-gray-300 relative overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-white/80 p-4 rounded-full">
                      <Star className="w-10 h-10 text-yellow-500" />
                    </div>
                  </div>
                  <div className="absolute top-3 left-3">
                    <Badge className="bg-yellow-400 text-gray-900 font-bold">
                      <Star className="w-3 h-3 mr-1 fill-gray-900" />
                      {negocio.rating}
                    </Badge>
                  </div>
                </div>

                {/* Content */}
                <div className="md:w-3/5 p-5">
                  <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-yellow-600 transition-colors">
                    {negocio.nombre}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                    {negocio.descripcion}
                  </p>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center text-gray-600">
                      <MapPin className="w-4 h-4 mr-2 text-gray-400" />
                      <span className="line-clamp-1">{negocio.direccion}</span>
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Phone className="w-4 h-4 mr-2 text-gray-400" />
                      {negocio.telefono}
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Clock className="w-4 h-4 mr-2 text-gray-400" />
                      <span className="line-clamp-1">{negocio.horario}</span>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t border-gray-100 flex items-center justify-between">
                    <span className="text-sm text-gray-500">
                      {negocio.productos?.length || 0} productos
                      {negocio.servicios?.length ? ` • ${negocio.servicios.length} servicios` : ''}
                    </span>
                    <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-yellow-500 group-hover:translate-x-1 transition-all" />
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {categoria.negocios.length === 0 && (
          <div className="text-center py-16">
            <div className="bg-gray-200 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Star className="w-10 h-10 text-gray-400" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">No hay negocios aún</h3>
            <p className="text-gray-600">Sé el primero en publicar en esta categoría</p>
          </div>
        )}
      </div>
    </div>
  );
}
