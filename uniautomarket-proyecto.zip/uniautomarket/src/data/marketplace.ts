import type { Categoria, Negocio } from '@/types';

export const categorias: Categoria[] = [
  {
    id: 'desarmadurias',
    nombre: 'Desarmadurías',
    descripcion: 'Encuentra repuestos usados y piezas de vehículos desarmados',
    imagen: '/images/categorias/desarmaduria.jpg',
    icono: 'Wrench',
    color: 'bg-amber-600',
    negocios: [
      {
        id: 'desarmaduria-el-pitazo',
        nombre: 'Desarmaduría El Pitazo',
        categoriaId: 'desarmadurias',
        imagen: '/images/negocios/desarmaduria-pitazo.jpg',
        direccion: 'Av. Las Torres 2856, Santiago',
        telefono: '+56 9 1234 5678',
        email: 'contacto@elpitazo.cl',
        horario: 'Lun - Vie: 8:30 - 18:00 | Sáb: 9:00 - 14:00',
        descripcion: 'Especialistas en repuestos de todas las marcas. Más de 20 años de experiencia en el rubro automotriz.',
        rating: 4.5,
        productos: [
          { id: 'p1', nombre: 'Motor Toyota Corolla 1.6', descripcion: 'Motor completo en buen estado, 80.000 km', precio: 850000, imagen: '/images/productos/motor-corolla.jpg', disponible: true },
          { id: 'p2', nombre: 'Caja de cambios Nissan', descripcion: 'Caja automática Nissan Sentra 2015', precio: 450000, imagen: '/images/productos/caja-nissan.jpg', disponible: true },
          { id: 'p3', nombre: 'Puerta delantera Chevrolet', descripcion: 'Puerta delantera izquierda Chevrolet Spark', precio: 85000, imagen: '/images/productos/puerta-chevrolet.jpg', disponible: true },
          { id: 'p4', nombre: 'Faros traseros Hyundai', descripcion: 'Par de faros traseros Hyundai Accent 2018', precio: 120000, imagen: '/images/productos/faros-hyundai.jpg', disponible: false },
        ]
      },
      {
        id: 'desarmaduria-san-carlos',
        nombre: 'Desarmaduría San Carlos',
        categoriaId: 'desarmadurias',
        imagen: '/images/negocios/desarmaduria-sancarlos.jpg',
        direccion: 'Calle San Carlos 1234, Maipú',
        telefono: '+56 9 8765 4321',
        email: 'ventas@sancarlos.cl',
        horario: 'Lun - Sáb: 8:00 - 18:00',
        descripcion: 'Gran stock de repuestos nacionales e importados. Garantía en todas nuestras piezas.',
        rating: 4.3,
        productos: [
          { id: 'p5', nombre: 'Transmisión Mazda 3', descripcion: 'Transmisión manual Mazda 3 2017', precio: 380000, imagen: '/images/productos/transmision-mazda.jpg', disponible: true },
          { id: 'p6', nombre: 'Parachoques delantero Kia', descripcion: 'Parachoques delantero Kia Rio 2019', precio: 95000, imagen: '/images/productos/parachoques-kia.jpg', disponible: true },
          { id: 'p7', nombre: 'Espejo retrovisor Ford', descripcion: 'Espejo lateral derecho Ford Fiesta', precio: 45000, imagen: '/images/productos/espejo-ford.jpg', disponible: true },
        ]
      },
      {
        id: 'desarmaduria-la-rapida',
        nombre: 'Desarmaduría La Rápida',
        categoriaId: 'desarmadurias',
        imagen: '/images/negocios/desarmaduria-rapida.jpg',
        direccion: 'Av. Vicuña Mackenna 5678, La Florida',
        telefono: '+56 9 2345 6789',
        email: 'info@larapida.cl',
        horario: 'Lun - Vie: 8:00 - 19:00 | Sáb: 9:00 - 15:00',
        descripcion: 'Despacho express en 24 horas. Especialistas en vehículos europeos y asiáticos.',
        rating: 4.7,
        productos: [
          { id: 'p8', nombre: 'Alternador BMW Serie 3', descripcion: 'Alternador original BMW 320i', precio: 280000, imagen: '/images/productos/alternador-bmw.jpg', disponible: true },
          { id: 'p9', nombre: 'Arranque Volkswagen', descripcion: 'Motor de arranque VW Golf 2016', precio: 165000, imagen: '/images/productos/arranque-vw.jpg', disponible: true },
          { id: 'p10', nombre: 'Radiador Honda Civic', descripcion: 'Radiador completo Honda Civic 2018', precio: 145000, imagen: '/images/productos/radiador-honda.jpg', disponible: true },
        ]
      }
    ]
  },
  {
    id: 'talleres',
    nombre: 'Talleres Mecánicos',
    descripcion: 'Servicios de reparación, mantención y diagnóstico vehicular',
    imagen: '/images/categorias/taller.jpg',
    icono: 'Settings',
    color: 'bg-blue-600',
    negocios: [
      {
        id: 'taller-mecanica-express',
        nombre: 'Mecánica Express',
        categoriaId: 'talleres',
        imagen: '/images/negocios/taller-express.jpg',
        direccion: 'Av. Irarrázaval 3456, Ñuñoa',
        telefono: '+56 9 3456 7890',
        email: 'agenda@mecanicaexpress.cl',
        horario: 'Lun - Vie: 8:00 - 19:00 | Sáb: 9:00 - 14:00',
        descripcion: 'Servicio rápido de mantención y reparaciones menores. Diagnóstico computacional gratuito.',
        rating: 4.6,
        servicios: [
          { id: 's1', nombre: 'Cambio de aceite', descripcion: 'Incluye aceite 10W40, filtro y revisión de 15 puntos', precioDesde: 35000, imagen: '/images/servicios/cambio-aceite.jpg' },
          { id: 's2', nombre: 'Alineación y balanceo', descripcion: 'Alineación computarizada y balanceo de 4 ruedas', precioDesde: 45000, imagen: '/images/servicios/alineacion.jpg' },
          { id: 's3', nombre: 'Revisión técnica pre ITV', descripcion: 'Revisión completa para pasar la revisión técnica sin problemas', precioDesde: 25000, imagen: '/images/servicios/revision-itv.jpg' },
          { id: 's4', nombre: 'Diagnóstico computacional', descripcion: 'Escaneo completo del sistema del vehículo', precioDesde: 15000, imagen: '/images/servicios/diagnostico.jpg' },
        ]
      },
      {
        id: 'taller-automotriz-pro',
        nombre: 'Automotriz Pro',
        categoriaId: 'talleres',
        imagen: '/images/negocios/taller-pro.jpg',
        direccion: 'Calle Los Olmos 789, Providencia',
        telefono: '+56 9 4567 8901',
        email: 'reservas@automotrizpro.cl',
        horario: 'Lun - Sáb: 8:30 - 18:30',
        descripcion: 'Taller multimarca con mecánicos certificados. Especialistas en vehículos de alta gama.',
        rating: 4.8,
        servicios: [
          { id: 's5', nombre: 'Mantención de 10.000 km', descripcion: 'Cambio de aceite, filtros, revisión de frenos y suspensión', precioDesde: 65000, imagen: '/images/servicios/mantencion-10k.jpg' },
          { id: 's6', nombre: 'Reparación de frenos', descripcion: 'Cambio de pastillas, discos y líquido de frenos', precioDesde: 55000, imagen: '/images/servicios/frenos.jpg' },
          { id: 's7', nombre: 'Servicio de suspensión', descripcion: 'Diagnóstico y reparación de amortiguadores y resortes', precioDesde: 85000, imagen: '/images/servicios/suspension.jpg' },
          { id: 's8', nombre: 'Cambio de embrague', descripcion: 'Reemplazo completo de kit de embrague', precioDesde: 280000, imagen: '/images/servicios/embrague.jpg' },
        ]
      },
      {
        id: 'taller-diagnostico-total',
        nombre: 'Diagnóstico Total',
        categoriaId: 'talleres',
        imagen: '/images/negocios/taller-diagnostico.jpg',
        direccion: 'Av. Kennedy 4567, Las Condes',
        telefono: '+56 9 5678 9012',
        email: 'contacto@diagnosticototal.cl',
        horario: 'Lun - Vie: 9:00 - 18:00',
        descripcion: 'Especialistas en diagnóstico electrónico y sistemas computacionales de vehículos.',
        rating: 4.9,
        servicios: [
          { id: 's9', nombre: 'Diagnóstico ECU', descripcion: 'Análisis completo de la unidad de control del motor', precioDesde: 45000, imagen: '/images/servicios/diagnostico-ecu.jpg' },
          { id: 's10', nombre: 'Programación de llaves', descripcion: 'Programación de llaves y controles remotos', precioDesde: 35000, imagen: '/images/servicios/llaves.jpg' },
          { id: 's11', nombre: 'Limpieza de inyectores', descripcion: 'Limpieza ultrasónica y calibración de inyectores', precioDesde: 75000, imagen: '/images/servicios/inyectores.jpg' },
        ]
      }
    ]
  },
  {
    id: 'herramientas',
    nombre: 'Herramientas',
    descripcion: 'Venta de herramientas especializadas para el rubro automotriz',
    imagen: '/images/categorias/herramientas.jpg',
    icono: 'Tool',
    color: 'bg-emerald-600',
    negocios: [
      {
        id: 'herramientas-auto-tools',
        nombre: 'Auto Tools Chile',
        categoriaId: 'herramientas',
        imagen: '/images/negocios/autotools.jpg',
        direccion: 'Av. Libertador Bernardo O\'Higgins 2345, Santiago',
        telefono: '+56 9 6789 0123',
        email: 'ventas@autotools.cl',
        horario: 'Lun - Vie: 9:00 - 18:30 | Sáb: 10:00 - 14:00',
        descripcion: 'Distribuidor oficial de las mejores marcas de herramientas. Garantía extendida en todos los productos.',
        rating: 4.7,
        productos: [
          { id: 'h1', nombre: 'Juego de dados 1/2" 94 piezas', descripcion: 'Set completo con criquet, extensiones y dados métricos', precio: 125000, imagen: '/images/productos/dados.jpg', disponible: true },
          { id: 'h2', nombre: 'Pistola de impacto neumática', descripcion: '1/2" 680 Nm, incluye dados de impacto', precio: 89000, imagen: '/images/productos/pistola-impacto.jpg', disponible: true },
          { id: 'h3', nombre: 'Gata hidráulica tipo caimán 3 ton', descripcion: 'Ideal para talleres, altura máxima 500mm', precio: 145000, imagen: '/images/productos/gata.jpg', disponible: true },
          { id: 'h4', nombre: 'Multímetro automotriz', descripcion: 'Con función de prueba de inyectores, sensores y cables', precio: 65000, imagen: '/images/productos/multimetro.jpg', disponible: true },
        ]
      },
      {
        id: 'herramientas-mecanica-pro',
        nombre: 'Mecánica Pro Herramientas',
        categoriaId: 'herramientas',
        imagen: '/images/negocios/mecanica-pro.jpg',
        direccion: 'Calle San Diego 567, Santiago',
        telefono: '+56 9 7890 1234',
        email: 'info@mecanicapro.cl',
        horario: 'Lun - Sáb: 9:00 - 19:00',
        descripcion: 'Herramientas profesionales para mecánicos. Precios mayoristas para talleres.',
        rating: 4.4,
        productos: [
          { id: 'h5', nombre: 'Extractor de rodamientos', descripcion: 'Set de 16 piezas para extracción interior y exterior', precio: 78000, imagen: '/images/productos/extractor.jpg', disponible: true },
          { id: 'h6', nombre: 'Compresor de resortes de válvula', descripcion: 'Herramienta universal para motores OHV y OHC', precio: 42000, imagen: '/images/productos/compresor-resortes.jpg', disponible: true },
          { id: 'h7', nombre: 'Juego de calibrador de válvulas', descripcion: '26 láminas en pulgadas y métrico', precio: 35000, imagen: '/images/productos/calibrador.jpg', disponible: false },
        ]
      }
    ]
  },
  {
    id: 'repuestos',
    nombre: 'Repuestos',
    descripcion: 'Venta de repuestos nuevos originales y alternativos',
    imagen: '/images/categorias/repuestos.jpg',
    icono: 'Package',
    color: 'bg-purple-600',
    negocios: [
      {
        id: 'repuestos-auto-partes',
        nombre: 'Auto Partes Express',
        categoriaId: 'repuestos',
        imagen: '/images/negocios/autopartes.jpg',
        direccion: 'Av. Recoleta 3456, Recoleta',
        telefono: '+56 9 8901 2345',
        email: 'pedidos@autopartes.cl',
        horario: 'Lun - Vie: 8:30 - 18:00 | Sáb: 9:00 - 14:00',
        descripcion: 'Repuestos originales y alternativos de calidad. Envíos a todo Chile en 24-48 horas.',
        rating: 4.5,
        productos: [
          { id: 'r1', nombre: 'Kit de embrague Valeo', descripcion: 'Para Toyota Corolla 2008-2013, incluye plato, disco y collarín', precio: 185000, imagen: '/images/productos/kit-embrague.jpg', disponible: true },
          { id: 'r2', nombre: 'Filtro de aceite Bosch', descripcion: 'Compatible con múltiples marcas, alta calidad alemana', precio: 8500, imagen: '/images/productos/filtro-aceite.jpg', disponible: true },
          { id: 'r3', nombre: 'Pastillas de freno Brembo', descripcion: 'Delanteras para Nissan Versa 2012-2019', precio: 45000, imagen: '/images/productos/pastillas-brembo.jpg', disponible: true },
          { id: 'r4', nombre: 'Batería Bosch 60Ah', descripcion: 'Garantía 18 meses, libre mantención', precio: 95000, imagen: '/images/productos/bateria.jpg', disponible: true },
        ]
      },
      {
        id: 'repuestos-motor-parts',
        nombre: 'Motor Parts Chile',
        categoriaId: 'repuestos',
        imagen: '/images/negocios/motorparts.jpg',
        direccion: 'Calle Victoria 890, Santiago',
        telefono: '+56 9 9012 3456',
        email: 'ventas@motorparts.cl',
        horario: 'Lun - Sáb: 8:00 - 18:00',
        descripcion: 'Especialistas en repuestos de motor, suspensión y transmisión.',
        rating: 4.6,
        productos: [
          { id: 'r5', nombre: 'Correa de distribución Gates', descripcion: 'Kit completo con tensores para VW Gol', precio: 125000, imagen: '/images/productos/correa-distribucion.jpg', disponible: true },
          { id: 'r6', nombre: 'Bomba de agua SKF', descripcion: 'Alta durabilidad, para Chevrolet Sail', precio: 45000, imagen: '/images/productos/bomba-agua.jpg', disponible: true },
          { id: 'r7', nombre: 'Kit de amortiguadores Monroe', descripcion: 'Par delantero con topes y fuelles', precio: 165000, imagen: '/images/productos/amortiguadores.jpg', disponible: true },
        ]
      }
    ]
  },
  {
    id: 'gruas',
    nombre: 'Grúas',
    descripcion: 'Servicios de remolque y traslado de vehículos',
    imagen: '/images/categorias/gruas.jpg',
    icono: 'Truck',
    color: 'bg-red-600',
    negocios: [
      {
        id: 'gruas-rapidas-24h',
        nombre: 'Grúas Rápidas 24H',
        categoriaId: 'gruas',
        imagen: '/images/negocios/gruas-rapidas.jpg',
        direccion: 'Av. Americo Vespucio 1234, Cerrillos',
        telefono: '+56 9 1111 2222',
        email: 'emergencias@gruasrapidas.cl',
        horario: '24 horas, 7 días a la semana',
        descripcion: 'Servicio de grúa disponible las 24 horas. Cobertura en toda la Región Metropolitana.',
        rating: 4.8,
        servicios: [
          { id: 'g1', nombre: 'Remolque local', descripcion: 'Traslado dentro de la misma comuna', precioDesde: 35000, imagen: '/images/servicios/remolque-local.jpg' },
          { id: 'g2', nombre: 'Remolque intercomunal', descripcion: 'Traslado entre comunas de Santiago', precioDesde: 55000, imagen: '/images/servicios/remolque-intercomunal.jpg' },
          { id: 'g3', nombre: 'Auxilio mecánico en ruta', descripcion: 'Cambio de neumático, paso de corriente, combustible', precioDesde: 25000, imagen: '/images/servicios/auxilio.jpg' },
          { id: 'g4', nombre: 'Traslado de vehículos especiales', descripcion: 'Para vehículos de lujo, clásicos o de alto valor', precioDesde: 85000, imagen: '/images/servicios/traslado-especial.jpg' },
        ]
      },
      {
        id: 'gruas-santiago-express',
        nombre: 'Grúas Santiago Express',
        categoriaId: 'gruas',
        imagen: '/images/negocios/gruas-express.jpg',
        direccion: 'Av. La Florida 5678, La Florida',
        telefono: '+56 9 3333 4444',
        email: 'contacto@gruasexpress.cl',
        horario: '24 horas, todos los días',
        descripcion: 'Tiempo de respuesta promedio 20 minutos. Flota moderna con seguro de carga.',
        rating: 4.6,
        servicios: [
          { id: 'g5', nombre: 'Servicio de grúa plana', descripcion: 'Ideal para vehículos bajos o averiados', precioDesde: 45000, imagen: '/images/servicios/grua-plana.jpg' },
          { id: 'g6', nombre: 'Rescate en carretera', descripcion: 'Servicio de emergencia en rutas interurbanas', precioDesde: 75000, imagen: '/images/servicios/rescate.jpg' },
          { id: 'g7', nombre: 'Traslado a taller mecánico', descripcion: 'Incluye coordinación con taller de su preferencia', precioDesde: 40000, imagen: '/images/servicios/traslado-taller.jpg' },
        ]
      }
    ]
  },
  {
    id: 'pintura',
    nombre: 'Pintura y Desabolladura',
    descripcion: 'Reparación de carrocería, pintura y desabolladura profesional',
    imagen: '/images/categorias/pintura.jpg',
    icono: 'Paintbrush',
    color: 'bg-cyan-600',
    negocios: [
      {
        id: 'pintura-carroceria-pro',
        nombre: 'Carrocería Pro',
        categoriaId: 'pintura',
        imagen: '/images/negocios/carroceria-pro.jpg',
        direccion: 'Av. Independencia 9012, Independencia',
        telefono: '+56 9 5555 6666',
        email: 'citas@carroceriapro.cl',
        horario: 'Lun - Vie: 8:00 - 18:00 | Sáb: 9:00 - 13:00',
        descripcion: 'Taller de pintura con cabina de pintura y horno de secado. Garantía de por vida en pintura.',
        rating: 4.9,
        servicios: [
          { id: 'pd1', nombre: 'Pintura completa', descripcion: 'Lijado, masillado, pintura y pulido completo del vehículo', precioDesde: 850000, imagen: '/images/servicios/pintura-completa.jpg' },
          { id: 'pd2', nombre: 'Desabolladura sin pintura', descripcion: 'Reparación de abolladuras manteniendo la pintura original', precioDesde: 45000, imagen: '/images/servicios/desabolladura.jpg' },
          { id: 'pd3', nombre: 'Pintura de panel', descripcion: 'Un panel (puerta, guardabarro, capó, etc.)', precioDesde: 125000, imagen: '/images/servicios/pintura-panel.jpg' },
          { id: 'pd4', nombre: 'Pulido y detailing', descripcion: 'Pulido de pintura y tratamiento cerámico', precioDesde: 95000, imagen: '/images/servicios/pulido.jpg' },
        ]
      },
      {
        id: 'pintura-perfect-finish',
        nombre: 'Perfect Finish',
        categoriaId: 'pintura',
        imagen: '/images/negocios/perfect-finish.jpg',
        direccion: 'Calle Matta 3456, San Miguel',
        telefono: '+56 9 7777 8888',
        email: 'info@perfectfinish.cl',
        horario: 'Lun - Sáb: 8:30 - 18:00',
        descripcion: 'Especialistas en pintura de alta calidad y reparación de carrocería. Presupuestos sin compromiso.',
        rating: 4.7,
        servicios: [
          { id: 'pd5', nombre: 'Reparación de choques', descripcion: 'Reparación completa de daños por accidentes', precioDesde: 250000, imagen: '/images/servicios/reparacion-choque.jpg' },
          { id: 'pd6', nombre: 'Cambio de color', descripcion: 'Pintura completa con cambio de color del vehículo', precioDesde: 1200000, imagen: '/images/servicios/cambio-color.jpg' },
          { id: 'pd7', nombre: 'Tratamiento anti óxido', descripcion: 'Limpieza, tratamiento y protección contra la corrosión', precioDesde: 85000, imagen: '/images/servicios/antioxido.jpg' },
        ]
      }
    ]
  },
  {
    id: 'scanner',
    nombre: 'Scanner y Diagnóstico',
    descripcion: 'Escaneo computacional y diagnóstico electrónico de vehículos',
    imagen: '/images/categorias/scanner.jpg',
    icono: 'Cpu',
    color: 'bg-indigo-600',
    negocios: [
      {
        id: 'scanner-diagnostico-pro',
        nombre: 'Diagnóstico Pro',
        categoriaId: 'scanner',
        imagen: '/images/negocios/scanner-pro.jpg',
        direccion: 'Av. Las Condes 7890, Las Condes',
        telefono: '+56 9 8888 9999',
        email: 'contacto@diagnosticopro.cl',
        horario: 'Lun - Vie: 9:00 - 19:00 | Sáb: 10:00 - 14:00',
        descripcion: 'Especialistas en diagnóstico computacional multimarca. Escaneo completo de sistemas electrónicos.',
        rating: 4.9,
        servicios: [
          { id: 'sc1', nombre: 'Escaneo completo del vehículo', descripcion: 'Diagnóstico de todos los módulos electrónicos del vehículo', precioDesde: 35000, imagen: '/images/servicios/escaneo.jpg' },
          { id: 'sc2', nombre: 'Lectura y borrado de códigos de falla', descripcion: 'Escaneo OBD2, lectura y eliminación de errores', precioDesde: 15000, imagen: '/images/servicios/codigos.jpg' },
          { id: 'sc3', nombre: 'Diagnóstico de airbag y ABS', descripcion: 'Análisis específico de sistemas de seguridad', precioDesde: 25000, imagen: '/images/servicios/airbag.jpg' },
          { id: 'sc4', nombre: 'Prueba de sensores y actuadores', descripcion: 'Verificación en tiempo real de componentes electrónicos', precioDesde: 30000, imagen: '/images/servicios/sensores.jpg' },
        ]
      },
      {
        id: 'scanner-auto-check',
        nombre: 'Auto Check Scanner',
        categoriaId: 'scanner',
        imagen: '/images/negocios/autocheck.jpg',
        direccion: 'Calle Providencia 3456, Providencia',
        telefono: '+56 9 7777 6666',
        email: 'info@autocheck.cl',
        horario: 'Lun - Sáb: 8:30 - 18:30',
        descripcion: 'Tecnología de punta en diagnóstico automotriz. Equipos originales de fábrica.',
        rating: 4.7,
        servicios: [
          { id: 'sc5', nombre: 'Diagnóstico pre-compra', descripcion: 'Revisión completa antes de comprar un vehículo usado', precioDesde: 45000, imagen: '/images/servicios/precompra.jpg' },
          { id: 'sc6', nombre: 'Análisis de consumo de combustible', descripcion: 'Diagnóstico de inyectores, sensores O2 y sistema de admisión', precioDesde: 28000, imagen: '/images/servicios/consumo.jpg' },
          { id: 'sc7', nombre: 'Reset de service y mantenciones', descripcion: 'Programación de intervalos de servicio', precioDesde: 12000, imagen: '/images/servicios/reset.jpg' },
        ]
      }
    ]
  },
  {
    id: 'electronica',
    nombre: 'Electrónica Automotriz',
    descripcion: 'Reparación de módulos, ECU, inyectores y sistemas electrónicos',
    imagen: '/images/categorias/electronica.jpg',
    icono: 'Zap',
    color: 'bg-violet-600',
    negocios: [
      {
        id: 'electronica-ecu-master',
        nombre: 'ECU Master Chile',
        categoriaId: 'electronica',
        imagen: '/images/negocios/ecu-master.jpg',
        direccion: 'Av. Vicuña Mackenna 9012, Macul',
        telefono: '+56 9 6666 5555',
        email: 'ventas@ecumaster.cl',
        horario: 'Lun - Vie: 9:00 - 18:00 | Sáb: 9:00 - 13:00',
        descripcion: 'Reparación y reprogramación de ECU. Especialistas en electrónica de potencia.',
        rating: 4.8,
        servicios: [
          { id: 'el1', nombre: 'Reparación de ECU', descripcion: 'Diagnóstico y reparación de unidades de control', precioDesde: 150000, imagen: '/images/servicios/ecu.jpg' },
          { id: 'el2', nombre: 'Reparación de tableros digitales', descripcion: 'Fix de pixeles, reparación de pantallas y clusters', precioDesde: 85000, imagen: '/images/servicios/tablero.jpg' },
          { id: 'el3', nombre: 'Reparación de inyectores', descripcion: 'Limpieza ultrasónica y reparación de inyectores electrónicos', precioDesde: 45000, imagen: '/images/servicios/inyector.jpg' },
          { id: 'el4', nombre: 'Reparación de módulos de confort', descripcion: 'Vidrios eléctricos, cierre centralizado, espejos', precioDesde: 65000, imagen: '/images/servicios/modulo.jpg' },
        ]
      },
      {
        id: 'electronica-auto-electric',
        nombre: 'Auto Electric Pro',
        categoriaId: 'electronica',
        imagen: '/images/negocios/autoelectric.jpg',
        direccion: 'Calle San Diego 789, Santiago',
        telefono: '+56 9 5555 4444',
        email: 'contacto@autoelectric.cl',
        horario: 'Lun - Sáb: 8:00 - 19:00',
        descripcion: 'Soluciones integrales en electricidad y electrónica automotriz. Garantía de 1 año.',
        rating: 4.6,
        servicios: [
          { id: 'el5', nombre: 'Instalación de alarmas', descripcion: 'Alarmas con cierre centralizado y levantavidrios', precioDesde: 120000, imagen: '/images/servicios/alarma.jpg' },
          { id: 'el6', nombre: 'Instalación de cámaras y sensores', descripcion: 'Cámara de retroceso, sensores de estacionamiento', precioDesde: 85000, imagen: '/images/servicios/camara.jpg' },
          { id: 'el7', nombre: 'Reparación de alternadores y arranques', descripcion: 'Rebobinado y reparación completa', precioDesde: 95000, imagen: '/images/servicios/alternador.jpg' },
        ]
      }
    ]
  },
  {
    id: 'reprogramacion',
    nombre: 'Reprogramación ECU',
    descripcion: 'Stage 1, 2, 3. Optimización de potencia y consumo. DPF/EGR off',
    imagen: '/images/categorias/reprogramacion.jpg',
    icono: 'Code',
    color: 'bg-fuchsia-600',
    negocios: [
      {
        id: 'repro-chip-performance',
        nombre: 'Chip Performance Chile',
        categoriaId: 'reprogramacion',
        imagen: '/images/negocios/chip-performance.jpg',
        direccion: 'Av. Kennedy 5678, Las Condes',
        telefono: '+56 9 4444 3333',
        email: 'info@chipperformance.cl',
        horario: 'Lun - Vie: 10:00 - 19:00 | Sáb: 10:00 - 14:00',
        descripcion: 'Reprogramación de ECU Stage 1, 2 y 3. Ganas hasta +50HP en tu vehículo.',
        rating: 4.9,
        servicios: [
          { id: 'rp1', nombre: 'Stage 1 - Optimización', descripcion: 'Aumento de potencia manteniendo confiabilidad', precioDesde: 250000, imagen: '/images/servicios/stage1.jpg' },
          { id: 'rp2', nombre: 'Stage 2 - Intercooler + Downpipe', descripcion: 'Reprogramación con modificaciones de hardware', precioDesde: 450000, imagen: '/images/servicios/stage2.jpg' },
          { id: 'rp3', nombre: 'Stage 3 - Turbo upgrade', descripcion: 'Máxima potencia con turbo mayor', precioDesde: 750000, imagen: '/images/servicios/stage3.jpg' },
          { id: 'rp4', nombre: 'DPF/EGR Off', descripcion: 'Eliminación de filtros de partículas y válvula EGR', precioDesde: 180000, imagen: '/images/servicios/dpf.jpg' },
        ]
      },
      {
        id: 'repro-tuning-pro',
        nombre: 'Tuning Pro Chile',
        categoriaId: 'reprogramacion',
        imagen: '/images/negocios/tuning-pro.jpg',
        direccion: 'Calle Apoquindo 1234, Las Condes',
        telefono: '+56 9 3333 2222',
        email: 'contacto@tuningpro.cl',
        horario: 'Lun - Sáb: 9:00 - 20:00',
        descripcion: 'Especialistas en remap de ECU. Software personalizado para cada vehículo.',
        rating: 4.8,
        servicios: [
          { id: 'rp5', nombre: 'Remap personalizado', descripcion: 'Programación a medida según tus necesidades', precioDesde: 300000, imagen: '/images/servicios/remap.jpg' },
          { id: 'rp6', nombre: 'Pop & Bang / Launch Control', descripcion: 'Sonidos deportivos y control de lanzamiento', precioDesde: 120000, imagen: '/images/servicios/popbang.jpg' },
          { id: 'rp7', nombre: 'Eliminación de limitador', descripcion: 'Remoción de limites de velocidad y RPM', precioDesde: 80000, imagen: '/images/servicios/limitador.jpg' },
          { id: 'rp8', nombre: 'Start/Stop Off', descripcion: 'Desactivación del sistema auto start/stop', precioDesde: 50000, imagen: '/images/servicios/startstop.jpg' },
        ]
      }
    ]
  }
];

export const getCategoriaById = (id: string): Categoria | undefined => {
  return categorias.find(cat => cat.id === id);
};

export const getNegocioById = (id: string): Negocio | undefined => {
  for (const categoria of categorias) {
    const negocio = categoria.negocios.find(neg => neg.id === id);
    if (negocio) return negocio;
  }
  return undefined;
};
