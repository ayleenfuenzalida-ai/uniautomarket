import { useState } from 'react';
import { useData } from '@/contexts/DataContext';
import { useCompany } from '@/contexts/CompanyContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter,
  DialogClose
} from '@/components/ui/dialog';
import { 
  Plus, 
  Edit2, 
  Trash2, 
  X, 
  ChevronDown, 
  ChevronRight,
  Package,
  Wrench,
  Settings,
  Truck,
  Paintbrush,
  Star,
  Cpu,
  Code,
  Zap,
  Building2,
  Save
} from 'lucide-react';
import type { Categoria, Negocio, Producto, Servicio } from '@/types';

const iconOptions = [
  { value: 'Wrench', label: 'Herramienta', icon: Wrench },
  { value: 'Settings', label: 'Configuración', icon: Settings },
  { value: 'Package', label: 'Paquete', icon: Package },
  { value: 'Truck', label: 'Camión', icon: Truck },
  { value: 'Paintbrush', label: 'Pincel', icon: Paintbrush },
  { value: 'Cpu', label: 'Scanner', icon: Cpu },
  { value: 'Zap', label: 'Electrónica', icon: Zap },
  { value: 'Code', label: 'Código', icon: Code },
];

const colorOptions = [
  { value: 'bg-amber-600', label: 'Ámbar', class: 'bg-amber-600' },
  { value: 'bg-blue-600', label: 'Azul', class: 'bg-blue-600' },
  { value: 'bg-emerald-600', label: 'Esmeralda', class: 'bg-emerald-600' },
  { value: 'bg-purple-600', label: 'Púrpura', class: 'bg-purple-600' },
  { value: 'bg-red-600', label: 'Rojo', class: 'bg-red-600' },
  { value: 'bg-cyan-600', label: 'Cyan', class: 'bg-cyan-600' },
  { value: 'bg-orange-600', label: 'Naranja', class: 'bg-orange-600' },
  { value: 'bg-indigo-600', label: 'Índigo', class: 'bg-indigo-600' },
  { value: 'bg-violet-600', label: 'Violeta', class: 'bg-violet-600' },
  { value: 'bg-fuchsia-600', label: 'Fucsia', class: 'bg-fuchsia-600' },
  { value: 'bg-pink-600', label: 'Rosa', class: 'bg-pink-600' },
];

interface AdminPageProps {
  onBack: () => void;
}

export function AdminPage({ onBack }: AdminPageProps) {
  const { 
    categorias, 
    updateCategoria, 
    deleteCategoria, 
    addCategoria,
    updateNegocio,
    deleteNegocio,
    addNegocio,
    updateProducto,
    deleteProducto,
    addProducto,
    updateServicio,
    deleteServicio,
    addServicio
  } = useData();

  const [expandedCategorias, setExpandedCategorias] = useState<string[]>([]);
  const [expandedNegocios, setExpandedNegocios] = useState<string[]>([]);

  const toggleCategoria = (id: string) => {
    setExpandedCategorias(prev => 
      prev.includes(id) ? prev.filter(c => c !== id) : [...prev, id]
    );
  };

  const toggleNegocio = (id: string) => {
    setExpandedNegocios(prev => 
      prev.includes(id) ? prev.filter(n => n !== id) : [...prev, id]
    );
  };

  const generateId = (prefix: string) => `${prefix}-${Date.now()}`;

  return (
    <div className="min-h-screen bg-[#0a0a0a] py-8">
      <div className="container mx-auto px-4 max-w-7xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Panel de Administración</h1>
            <p className="text-gray-400">Gestiona categorías, negocios, productos y servicios</p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={onBack} className="border-gray-700 text-white hover:bg-gray-800">
              <X className="w-4 h-4 mr-2" />
              Cerrar
            </Button>
          </div>
        </div>

        <Tabs defaultValue="categorias" className="w-full">
          <TabsList className="bg-[#111111] border border-gray-800 mb-6 flex flex-wrap">
            <TabsTrigger value="categorias" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              Categorías
            </TabsTrigger>
            <TabsTrigger value="negocios" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              Negocios
            </TabsTrigger>
            <TabsTrigger value="productos" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              Productos
            </TabsTrigger>
            <TabsTrigger value="servicios" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              Servicios
            </TabsTrigger>
            <TabsTrigger value="empresa" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              <Building2 className="w-4 h-4 mr-2" />
              Empresa
            </TabsTrigger>
          </TabsList>

          {/* CATEGORIAS TAB */}
          <TabsContent value="categorias">
            <Card className="bg-[#111111] border-gray-800">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-white">Categorías</CardTitle>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="bg-red-600 hover:bg-red-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Nueva Categoría
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-[#1a1a1a] border-gray-700 text-white max-w-lg">
                    <DialogHeader>
                      <DialogTitle>Crear Nueva Categoría</DialogTitle>
                    </DialogHeader>
                    <CategoriaForm 
                      onSave={(categoria) => addCategoria({ ...categoria, id: generateId('cat'), negocios: [] })} 
                    />
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {categorias.map(categoria => (
                    <Card key={categoria.id} className="bg-[#1a1a1a] border-gray-700">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-3">
                            <div className={`${categoria.color} p-3 rounded-lg`}>
                              {iconOptions.find(i => i.value === categoria.icono)?.icon && 
                                (() => {
                                  const Icon = iconOptions.find(i => i.value === categoria.icono)!.icon;
                                  return <Icon className="w-5 h-5 text-white" />;
                                })()
                              }
                            </div>
                            <div>
                              <h3 className="font-semibold text-white">{categoria.nombre}</h3>
                              <p className="text-sm text-gray-400">{categoria.negocios.length} negocios</p>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white hover:bg-gray-700">
                                  <Edit2 className="w-4 h-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="bg-[#1a1a1a] border-gray-700 text-white max-w-lg">
                                <DialogHeader>
                                  <DialogTitle>Editar Categoría</DialogTitle>
                                </DialogHeader>
                                <CategoriaForm 
                                  categoria={categoria}
                                  onSave={updateCategoria} 
                                />
                              </DialogContent>
                            </Dialog>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="text-gray-400 hover:text-red-500 hover:bg-red-500/10"
                              onClick={() => deleteCategoria(categoria.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* NEGOCIOS TAB */}
          <TabsContent value="negocios">
            <Card className="bg-[#111111] border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Negocios</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {categorias.map(categoria => (
                    <div key={categoria.id} className="border border-gray-800 rounded-lg overflow-hidden">
                      <button
                        onClick={() => toggleCategoria(categoria.id)}
                        className="w-full flex items-center justify-between p-4 bg-[#1a1a1a] hover:bg-[#222222] transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`${categoria.color} p-2 rounded`}>
                            {iconOptions.find(i => i.value === categoria.icono)?.icon && 
                              (() => {
                                const Icon = iconOptions.find(i => i.value === categoria.icono)!.icon;
                                return <Icon className="w-4 h-4 text-white" />;
                              })()
                            }
                          </div>
                          <span className="font-medium text-white">{categoria.nombre}</span>
                          <Badge variant="secondary" className="bg-gray-800 text-gray-300">
                            {categoria.negocios.length} negocios
                          </Badge>
                        </div>
                        {expandedCategorias.includes(categoria.id) ? 
                          <ChevronDown className="w-5 h-5 text-gray-400" /> : 
                          <ChevronRight className="w-5 h-5 text-gray-400" />
                        }
                      </button>
                      
                      {expandedCategorias.includes(categoria.id) && (
                        <div className="p-4 bg-[#0a0a0a] space-y-3">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm" className="border-gray-700 text-gray-300 hover:bg-gray-800">
                                <Plus className="w-4 h-4 mr-2" />
                                Agregar Negocio
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="bg-[#1a1a1a] border-gray-700 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
                              <DialogHeader>
                                <DialogTitle>Nuevo Negocio - {categoria.nombre}</DialogTitle>
                              </DialogHeader>
                              <NegocioForm 
                                onSave={(negocio) => addNegocio(categoria.id, { 
                                  ...negocio, 
                                  id: generateId('neg'), 
                                  categoriaId: categoria.id,
                                  productos: [],
                                  servicios: []
                                })} 
                              />
                            </DialogContent>
                          </Dialog>

                          {categoria.negocios.map(negocio => (
                            <Card key={negocio.id} className="bg-[#1a1a1a] border-gray-700">
                              <CardContent className="p-4">
                                <div className="flex items-start justify-between">
                                  <div>
                                    <div className="flex items-center gap-2">
                                      <h4 className="font-medium text-white">{negocio.nombre}</h4>
                                      <div className="flex items-center text-yellow-500">
                                        <Star className="w-3 h-3 fill-current" />
                                        <span className="text-xs ml-1">{negocio.rating}</span>
                                      </div>
                                    </div>
                                    <p className="text-sm text-gray-400 mt-1">{negocio.direccion}</p>
                                    <p className="text-sm text-gray-500">{negocio.telefono}</p>
                                  </div>
                                  <div className="flex gap-2">
                                    <Dialog>
                                      <DialogTrigger asChild>
                                        <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white hover:bg-gray-700">
                                          <Edit2 className="w-4 h-4" />
                                        </Button>
                                      </DialogTrigger>
                                      <DialogContent className="bg-[#1a1a1a] border-gray-700 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
                                        <DialogHeader>
                                          <DialogTitle>Editar Negocio</DialogTitle>
                                        </DialogHeader>
                                        <NegocioForm 
                                          negocio={negocio}
                                          onSave={(n) => updateNegocio(categoria.id, n)} 
                                        />
                                      </DialogContent>
                                    </Dialog>
                                    <Button 
                                      variant="ghost" 
                                      size="icon" 
                                      className="text-gray-400 hover:text-red-500 hover:bg-red-500/10"
                                      onClick={() => deleteNegocio(categoria.id, negocio.id)}
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </Button>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* PRODUCTOS TAB */}
          <TabsContent value="productos">
            <Card className="bg-[#111111] border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Productos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {categorias.map(categoria => (
                    <div key={categoria.id} className="border border-gray-800 rounded-lg overflow-hidden">
                      <button
                        onClick={() => toggleCategoria(categoria.id)}
                        className="w-full flex items-center justify-between p-4 bg-[#1a1a1a] hover:bg-[#222222] transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`${categoria.color} p-2 rounded`}>
                            {iconOptions.find(i => i.value === categoria.icono)?.icon && 
                              (() => {
                                const Icon = iconOptions.find(i => i.value === categoria.icono)!.icon;
                                return <Icon className="w-4 h-4 text-white" />;
                              })()
                            }
                          </div>
                          <span className="font-medium text-white">{categoria.nombre}</span>
                        </div>
                        {expandedCategorias.includes(categoria.id) ? 
                          <ChevronDown className="w-5 h-5 text-gray-400" /> : 
                          <ChevronRight className="w-5 h-5 text-gray-400" />
                        }
                      </button>
                      
                      {expandedCategorias.includes(categoria.id) && (
                        <div className="p-4 bg-[#0a0a0a] space-y-3">
                          {categoria.negocios.map(negocio => (
                            <div key={negocio.id} className="border border-gray-800 rounded-lg overflow-hidden">
                              <button
                                onClick={() => toggleNegocio(negocio.id)}
                                className="w-full flex items-center justify-between p-3 bg-[#151515] hover:bg-[#1a1a1a] transition-colors"
                              >
                                <span className="text-sm font-medium text-gray-300">{negocio.nombre}</span>
                                <div className="flex items-center gap-2">
                                  <Badge variant="secondary" className="bg-gray-800 text-gray-400">
                                    {negocio.productos?.length || 0} productos
                                  </Badge>
                                  {expandedNegocios.includes(negocio.id) ? 
                                    <ChevronDown className="w-4 h-4 text-gray-500" /> : 
                                    <ChevronRight className="w-4 h-4 text-gray-500" />
                                  }
                                </div>
                              </button>

                              {expandedNegocios.includes(negocio.id) && (
                                <div className="p-3 space-y-2">
                                  <Dialog>
                                    <DialogTrigger asChild>
                                      <Button variant="outline" size="sm" className="border-gray-700 text-gray-300 hover:bg-gray-800">
                                        <Plus className="w-3 h-3 mr-2" />
                                        Agregar Producto
                                      </Button>
                                    </DialogTrigger>
                                    <DialogContent className="bg-[#1a1a1a] border-gray-700 text-white max-w-lg">
                                      <DialogHeader>
                                        <DialogTitle>Nuevo Producto - {negocio.nombre}</DialogTitle>
                                      </DialogHeader>
                                      <ProductoForm 
                                        onSave={(producto) => addProducto(categoria.id, negocio.id, { 
                                          ...producto, 
                                          id: generateId('prod')
                                        })} 
                                      />
                                    </DialogContent>
                                  </Dialog>

                                  {negocio.productos?.map(producto => (
                                    <div key={producto.id} className="flex items-center justify-between p-3 bg-[#1a1a1a] rounded border border-gray-800">
                                      <div>
                                        <div className="flex items-center gap-2">
                                          <span className="text-white font-medium">{producto.nombre}</span>
                                          {producto.disponible ? (
                                            <Badge className="bg-green-600/20 text-green-400 border-green-600/30 text-xs">Disponible</Badge>
                                          ) : (
                                            <Badge className="bg-red-600/20 text-red-400 border-red-600/30 text-xs">Agotado</Badge>
                                          )}
                                        </div>
                                        <p className="text-sm text-gray-400">${producto.precio.toLocaleString()}</p>
                                      </div>
                                      <div className="flex gap-1">
                                        <Dialog>
                                          <DialogTrigger asChild>
                                            <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-white">
                                              <Edit2 className="w-3 h-3" />
                                            </Button>
                                          </DialogTrigger>
                                          <DialogContent className="bg-[#1a1a1a] border-gray-700 text-white max-w-lg">
                                            <DialogHeader>
                                              <DialogTitle>Editar Producto</DialogTitle>
                                            </DialogHeader>
                                            <ProductoForm 
                                              producto={producto}
                                              onSave={(p) => updateProducto(categoria.id, negocio.id, p)} 
                                            />
                                          </DialogContent>
                                        </Dialog>
                                        <Button 
                                          variant="ghost" 
                                          size="icon" 
                                          className="h-8 w-8 text-gray-400 hover:text-red-500"
                                          onClick={() => deleteProducto(categoria.id, negocio.id, producto.id)}
                                        >
                                          <Trash2 className="w-3 h-3" />
                                        </Button>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* SERVICIOS TAB */}
          <TabsContent value="servicios">
            <Card className="bg-[#111111] border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Servicios</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {categorias.map(categoria => (
                    <div key={categoria.id} className="border border-gray-800 rounded-lg overflow-hidden">
                      <button
                        onClick={() => toggleCategoria(categoria.id)}
                        className="w-full flex items-center justify-between p-4 bg-[#1a1a1a] hover:bg-[#222222] transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`${categoria.color} p-2 rounded`}>
                            {iconOptions.find(i => i.value === categoria.icono)?.icon && 
                              (() => {
                                const Icon = iconOptions.find(i => i.value === categoria.icono)!.icon;
                                return <Icon className="w-4 h-4 text-white" />;
                              })()
                            }
                          </div>
                          <span className="font-medium text-white">{categoria.nombre}</span>
                        </div>
                        {expandedCategorias.includes(categoria.id) ? 
                          <ChevronDown className="w-5 h-5 text-gray-400" /> : 
                          <ChevronRight className="w-5 h-5 text-gray-400" />
                        }
                      </button>
                      
                      {expandedCategorias.includes(categoria.id) && (
                        <div className="p-4 bg-[#0a0a0a] space-y-3">
                          {categoria.negocios.filter(n => n.servicios && n.servicios.length > 0).map(negocio => (
                            <div key={negocio.id} className="border border-gray-800 rounded-lg overflow-hidden">
                              <button
                                onClick={() => toggleNegocio(negocio.id)}
                                className="w-full flex items-center justify-between p-3 bg-[#151515] hover:bg-[#1a1a1a] transition-colors"
                              >
                                <span className="text-sm font-medium text-gray-300">{negocio.nombre}</span>
                                <div className="flex items-center gap-2">
                                  <Badge variant="secondary" className="bg-gray-800 text-gray-400">
                                    {negocio.servicios?.length || 0} servicios
                                  </Badge>
                                  {expandedNegocios.includes(negocio.id) ? 
                                    <ChevronDown className="w-4 h-4 text-gray-500" /> : 
                                    <ChevronRight className="w-4 h-4 text-gray-500" />
                                  }
                                </div>
                              </button>

                              {expandedNegocios.includes(negocio.id) && (
                                <div className="p-3 space-y-2">
                                  <Dialog>
                                    <DialogTrigger asChild>
                                      <Button variant="outline" size="sm" className="border-gray-700 text-gray-300 hover:bg-gray-800">
                                        <Plus className="w-3 h-3 mr-2" />
                                        Agregar Servicio
                                      </Button>
                                    </DialogTrigger>
                                    <DialogContent className="bg-[#1a1a1a] border-gray-700 text-white max-w-lg">
                                      <DialogHeader>
                                        <DialogTitle>Nuevo Servicio - {negocio.nombre}</DialogTitle>
                                      </DialogHeader>
                                      <ServicioForm 
                                        onSave={(servicio) => addServicio(categoria.id, negocio.id, { 
                                          ...servicio, 
                                          id: generateId('serv')
                                        })} 
                                      />
                                    </DialogContent>
                                  </Dialog>

                                  {negocio.servicios?.map(servicio => (
                                    <div key={servicio.id} className="flex items-center justify-between p-3 bg-[#1a1a1a] rounded border border-gray-800">
                                      <div>
                                        <span className="text-white font-medium">{servicio.nombre}</span>
                                        <p className="text-sm text-gray-400">Desde ${servicio.precioDesde.toLocaleString()}</p>
                                      </div>
                                      <div className="flex gap-1">
                                        <Dialog>
                                          <DialogTrigger asChild>
                                            <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-white">
                                              <Edit2 className="w-3 h-3" />
                                            </Button>
                                          </DialogTrigger>
                                          <DialogContent className="bg-[#1a1a1a] border-gray-700 text-white max-w-lg">
                                            <DialogHeader>
                                              <DialogTitle>Editar Servicio</DialogTitle>
                                            </DialogHeader>
                                            <ServicioForm 
                                              servicio={servicio}
                                              onSave={(s) => updateServicio(categoria.id, negocio.id, s)} 
                                            />
                                          </DialogContent>
                                        </Dialog>
                                        <Button 
                                          variant="ghost" 
                                          size="icon" 
                                          className="h-8 w-8 text-gray-400 hover:text-red-500"
                                          onClick={() => deleteServicio(categoria.id, negocio.id, servicio.id)}
                                        >
                                          <Trash2 className="w-3 h-3" />
                                        </Button>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* EMPRESA TAB */}
          <TabsContent value="empresa">
            <CompanyDataForm />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// FORM COMPONENTS

function CompanyDataForm() {
  const { companyData, updateCompanyData } = useCompany();
  const [formData, setFormData] = useState(companyData);
  const [saved, setSaved] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateCompanyData(formData);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <Card className="bg-[#111111] border-gray-800">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Building2 className="w-5 h-5 text-red-500" />
          Datos de la Empresa
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Información General */}
          <div className="border border-gray-800 rounded-lg p-4">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              <span className="w-2 h-2 bg-red-500 rounded-full" />
              Información General
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="nombre">Nombre de la Empresa</Label>
                <Input
                  id="nombre"
                  value={formData.nombre}
                  onChange={e => setFormData({ ...formData, nombre: e.target.value })}
                  className="bg-[#222222] border-gray-700 text-white"
                />
              </div>
              <div>
                <Label htmlFor="slogan">Slogan</Label>
                <Input
                  id="slogan"
                  value={formData.slogan}
                  onChange={e => setFormData({ ...formData, slogan: e.target.value })}
                  className="bg-[#222222] border-gray-700 text-white"
                />
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="descripcion">Descripción</Label>
                <Textarea
                  id="descripcion"
                  value={formData.descripcion}
                  onChange={e => setFormData({ ...formData, descripcion: e.target.value })}
                  className="bg-[#222222] border-gray-700 text-white"
                  rows={3}
                />
              </div>
            </div>
          </div>

          {/* Contacto */}
          <div className="border border-gray-800 rounded-lg p-4">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              <span className="w-2 h-2 bg-red-500 rounded-full" />
              Información de Contacto
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <Label htmlFor="direccion">Dirección Completa</Label>
                <Textarea
                  id="direccion"
                  value={formData.direccion}
                  onChange={e => setFormData({ ...formData, direccion: e.target.value })}
                  className="bg-[#222222] border-gray-700 text-white"
                  rows={2}
                />
              </div>
              <div>
                <Label htmlFor="telefono">Teléfono</Label>
                <Input
                  id="telefono"
                  value={formData.telefono}
                  onChange={e => setFormData({ ...formData, telefono: e.target.value })}
                  className="bg-[#222222] border-gray-700 text-white"
                  placeholder="+56 2 XXXX XXXX"
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  className="bg-[#222222] border-gray-700 text-white"
                />
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="horario">Horario de Atención</Label>
                <Input
                  id="horario"
                  value={formData.horario}
                  onChange={e => setFormData({ ...formData, horario: e.target.value })}
                  className="bg-[#222222] border-gray-700 text-white"
                  placeholder="Lunes a Viernes: 9:00 - 18:00 hrs"
                />
              </div>
            </div>
          </div>

          {/* Redes Sociales */}
          <div className="border border-gray-800 rounded-lg p-4">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              <span className="w-2 h-2 bg-red-500 rounded-full" />
              Redes Sociales
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="facebook">Facebook URL</Label>
                <Input
                  id="facebook"
                  value={formData.redesSociales.facebook}
                  onChange={e => setFormData({ 
                    ...formData, 
                    redesSociales: { ...formData.redesSociales, facebook: e.target.value }
                  })}
                  className="bg-[#222222] border-gray-700 text-white"
                  placeholder="https://facebook.com/..."
                />
              </div>
              <div>
                <Label htmlFor="instagram">Instagram URL</Label>
                <Input
                  id="instagram"
                  value={formData.redesSociales.instagram}
                  onChange={e => setFormData({ 
                    ...formData, 
                    redesSociales: { ...formData.redesSociales, instagram: e.target.value }
                  })}
                  className="bg-[#222222] border-gray-700 text-white"
                  placeholder="https://instagram.com/..."
                />
              </div>
              <div>
                <Label htmlFor="twitter">Twitter URL</Label>
                <Input
                  id="twitter"
                  value={formData.redesSociales.twitter}
                  onChange={e => setFormData({ 
                    ...formData, 
                    redesSociales: { ...formData.redesSociales, twitter: e.target.value }
                  })}
                  className="bg-[#222222] border-gray-700 text-white"
                  placeholder="https://twitter.com/..."
                />
              </div>
              <div>
                <Label htmlFor="youtube">YouTube URL</Label>
                <Input
                  id="youtube"
                  value={formData.redesSociales.youtube}
                  onChange={e => setFormData({ 
                    ...formData, 
                    redesSociales: { ...formData.redesSociales, youtube: e.target.value }
                  })}
                  className="bg-[#222222] border-gray-700 text-white"
                  placeholder="https://youtube.com/..."
                />
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="whatsapp">WhatsApp Link</Label>
                <Input
                  id="whatsapp"
                  value={formData.redesSociales.whatsapp}
                  onChange={e => setFormData({ 
                    ...formData, 
                    redesSociales: { ...formData.redesSociales, whatsapp: e.target.value }
                  })}
                  className="bg-[#222222] border-gray-700 text-white"
                  placeholder="https://wa.me/569..."
                />
              </div>
            </div>
          </div>

          {/* Botón Guardar */}
          <div className="flex items-center gap-4">
            <Button 
              type="submit" 
              className="bg-red-600 hover:bg-red-700"
            >
              <Save className="w-4 h-4 mr-2" />
              Guardar Cambios
            </Button>
            {saved && (
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                ¡Cambios guardados!
              </Badge>
            )}
          </div>

          {/* Vista Previa */}
          <div className="border border-gray-800 rounded-lg p-4 mt-6">
            <h3 className="text-white font-semibold mb-4">Vista Previa del Footer</h3>
            <div className="bg-[#0a0a0a] rounded-lg p-4 border border-gray-800">
              <p className="text-gray-400 text-sm"><strong className="text-white">Nombre:</strong> {formData.nombre}</p>
              <p className="text-gray-400 text-sm"><strong className="text-white">Slogan:</strong> {formData.slogan}</p>
              <p className="text-gray-400 text-sm"><strong className="text-white">Dirección:</strong> {formData.direccion}</p>
              <p className="text-gray-400 text-sm"><strong className="text-white">Teléfono:</strong> {formData.telefono}</p>
              <p className="text-gray-400 text-sm"><strong className="text-white">Email:</strong> {formData.email}</p>
              <p className="text-gray-400 text-sm"><strong className="text-white">Horario:</strong> {formData.horario}</p>
            </div>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

function CategoriaForm({ categoria, onSave }: { categoria?: Categoria; onSave: (c: Categoria) => void }) {
  const [formData, setFormData] = useState<Partial<Categoria>>(categoria || {
    nombre: '',
    descripcion: '',
    icono: 'Wrench',
    color: 'bg-red-600',
    imagen: '/images/categorias/default.jpg',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData as Categoria);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="nombre">Nombre</Label>
        <Input
          id="nombre"
          value={formData.nombre}
          onChange={e => setFormData({ ...formData, nombre: e.target.value })}
          className="bg-[#222222] border-gray-700 text-white"
          placeholder="Ej: Desarmadurías"
        />
      </div>
      <div>
        <Label htmlFor="descripcion">Descripción</Label>
        <Textarea
          id="descripcion"
          value={formData.descripcion}
          onChange={e => setFormData({ ...formData, descripcion: e.target.value })}
          className="bg-[#222222] border-gray-700 text-white"
          placeholder="Descripción de la categoría..."
        />
      </div>
      <div>
        <Label>Icono</Label>
        <div className="grid grid-cols-5 gap-2 mt-2">
          {iconOptions.map(icon => (
            <button
              key={icon.value}
              type="button"
              onClick={() => setFormData({ ...formData, icono: icon.value })}
              className={`p-3 rounded-lg border transition-all ${
                formData.icono === icon.value 
                  ? 'border-red-500 bg-red-500/20' 
                  : 'border-gray-700 hover:border-gray-600'
              }`}
            >
              <icon.icon className={`w-5 h-5 mx-auto ${formData.icono === icon.value ? 'text-red-500' : 'text-gray-400'}`} />
              <span className="text-xs text-gray-500 mt-1 block">{icon.label}</span>
            </button>
          ))}
        </div>
      </div>
      <div>
        <Label>Color</Label>
        <div className="grid grid-cols-4 gap-2 mt-2">
          {colorOptions.map(color => (
            <button
              key={color.value}
              type="button"
              onClick={() => setFormData({ ...formData, color: color.value })}
              className={`p-3 rounded-lg border transition-all ${
                formData.color === color.value 
                  ? 'border-white' 
                  : 'border-gray-700 hover:border-gray-600'
              }`}
            >
              <div className={`w-6 h-6 rounded mx-auto ${color.class}`} />
              <span className="text-xs text-gray-500 mt-1 block">{color.label}</span>
            </button>
          ))}
        </div>
      </div>
      <DialogFooter>
        <DialogClose asChild>
          <Button type="button" variant="outline" className="border-gray-700 text-gray-300">Cancelar</Button>
        </DialogClose>
        <DialogClose asChild>
          <Button type="submit" className="bg-red-600 hover:bg-red-700">Guardar</Button>
        </DialogClose>
      </DialogFooter>
    </form>
  );
}

function NegocioForm({ negocio, onSave }: { negocio?: Negocio; onSave: (n: Negocio) => void }) {
  const [formData, setFormData] = useState<Partial<Negocio>>(negocio || {
    nombre: '',
    descripcion: '',
    direccion: '',
    telefono: '',
    email: '',
    horario: '',
    rating: 4.5,
    imagen: '/images/negocios/default.jpg',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData as Negocio);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="nombre">Nombre del Negocio</Label>
        <Input
          id="nombre"
          value={formData.nombre}
          onChange={e => setFormData({ ...formData, nombre: e.target.value })}
          className="bg-[#222222] border-gray-700 text-white"
        />
      </div>
      <div>
        <Label htmlFor="descripcion">Descripción</Label>
        <Textarea
          id="descripcion"
          value={formData.descripcion}
          onChange={e => setFormData({ ...formData, descripcion: e.target.value })}
          className="bg-[#222222] border-gray-700 text-white"
        />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="direccion">Dirección</Label>
          <Input
            id="direccion"
            value={formData.direccion}
            onChange={e => setFormData({ ...formData, direccion: e.target.value })}
            className="bg-[#222222] border-gray-700 text-white"
          />
        </div>
        <div>
          <Label htmlFor="telefono">Teléfono</Label>
          <Input
            id="telefono"
            value={formData.telefono}
            onChange={e => setFormData({ ...formData, telefono: e.target.value })}
            className="bg-[#222222] border-gray-700 text-white"
            placeholder="+56 9 XXXX XXXX"
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={e => setFormData({ ...formData, email: e.target.value })}
            className="bg-[#222222] border-gray-700 text-white"
          />
        </div>
        <div>
          <Label htmlFor="rating">Rating (0-5)</Label>
          <Input
            id="rating"
            type="number"
            min="0"
            max="5"
            step="0.1"
            value={formData.rating}
            onChange={e => setFormData({ ...formData, rating: parseFloat(e.target.value) })}
            className="bg-[#222222] border-gray-700 text-white"
          />
        </div>
      </div>
      <div>
        <Label htmlFor="horario">Horario</Label>
        <Input
          id="horario"
          value={formData.horario}
          onChange={e => setFormData({ ...formData, horario: e.target.value })}
          className="bg-[#222222] border-gray-700 text-white"
          placeholder="Lun - Vie: 9:00 - 18:00"
        />
      </div>
      <DialogFooter>
        <DialogClose asChild>
          <Button type="button" variant="outline" className="border-gray-700 text-gray-300">Cancelar</Button>
        </DialogClose>
        <DialogClose asChild>
          <Button type="submit" className="bg-red-600 hover:bg-red-700">Guardar</Button>
        </DialogClose>
      </DialogFooter>
    </form>
  );
}

function ProductoForm({ producto, onSave }: { producto?: Producto; onSave: (p: Producto) => void }) {
  const [formData, setFormData] = useState<Partial<Producto>>(producto || {
    nombre: '',
    descripcion: '',
    precio: 0,
    disponible: true,
    imagen: '/images/productos/default.jpg',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData as Producto);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="nombre">Nombre del Producto</Label>
        <Input
          id="nombre"
          value={formData.nombre}
          onChange={e => setFormData({ ...formData, nombre: e.target.value })}
          className="bg-[#222222] border-gray-700 text-white"
        />
      </div>
      <div>
        <Label htmlFor="descripcion">Descripción</Label>
        <Textarea
          id="descripcion"
          value={formData.descripcion}
          onChange={e => setFormData({ ...formData, descripcion: e.target.value })}
          className="bg-[#222222] border-gray-700 text-white"
        />
      </div>
      <div>
        <Label htmlFor="precio">Precio ($)</Label>
        <Input
          id="precio"
          type="number"
          value={formData.precio}
          onChange={e => setFormData({ ...formData, precio: parseInt(e.target.value) || 0 })}
          className="bg-[#222222] border-gray-700 text-white"
        />
      </div>
      <div className="flex items-center gap-2">
        <input
          type="checkbox"
          id="disponible"
          checked={formData.disponible}
          onChange={e => setFormData({ ...formData, disponible: e.target.checked })}
          className="w-4 h-4 rounded border-gray-700 bg-[#222222]"
        />
        <Label htmlFor="disponible" className="mb-0">Disponible</Label>
      </div>
      <DialogFooter>
        <DialogClose asChild>
          <Button type="button" variant="outline" className="border-gray-700 text-gray-300">Cancelar</Button>
        </DialogClose>
        <DialogClose asChild>
          <Button type="submit" className="bg-red-600 hover:bg-red-700">Guardar</Button>
        </DialogClose>
      </DialogFooter>
    </form>
  );
}

function ServicioForm({ servicio, onSave }: { servicio?: Servicio; onSave: (s: Servicio) => void }) {
  const [formData, setFormData] = useState<Partial<Servicio>>(servicio || {
    nombre: '',
    descripcion: '',
    precioDesde: 0,
    imagen: '/images/servicios/default.jpg',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData as Servicio);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="nombre">Nombre del Servicio</Label>
        <Input
          id="nombre"
          value={formData.nombre}
          onChange={e => setFormData({ ...formData, nombre: e.target.value })}
          className="bg-[#222222] border-gray-700 text-white"
        />
      </div>
      <div>
        <Label htmlFor="descripcion">Descripción</Label>
        <Textarea
          id="descripcion"
          value={formData.descripcion}
          onChange={e => setFormData({ ...formData, descripcion: e.target.value })}
          className="bg-[#222222] border-gray-700 text-white"
        />
      </div>
      <div>
        <Label htmlFor="precioDesde">Precio Desde ($)</Label>
        <Input
          id="precioDesde"
          type="number"
          value={formData.precioDesde}
          onChange={e => setFormData({ ...formData, precioDesde: parseInt(e.target.value) || 0 })}
          className="bg-[#222222] border-gray-700 text-white"
        />
      </div>
      <DialogFooter>
        <DialogClose asChild>
          <Button type="button" variant="outline" className="border-gray-700 text-gray-300">Cancelar</Button>
        </DialogClose>
        <DialogClose asChild>
          <Button type="submit" className="bg-red-600 hover:bg-red-700">Guardar</Button>
        </DialogClose>
      </DialogFooter>
    </form>
  );
}
