import { useState } from 'react';
import { Search, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useData } from '@/contexts/DataContext';

interface HeroSectionProps {
  onCategoriaClick: (categoriaId: string) => void;
}

export function HeroSection({ onCategoriaClick }: HeroSectionProps) {
  const { categorias } = useData();
  const [searchValue, setSearchValue] = useState('');
  const categoriasDestacadas = categorias.filter(c => c.destacada).slice(0, 4);

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-cover bg-center bg-fixed" style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=1920&q=80)' }} />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a]/90 via-[#0a0a0a]/70 to-[#0a0a0a]" />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-500/20 border border-red-500/30 rounded-full mb-8">
            <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
            <span className="text-red-400 text-sm font-medium">El marketplace #1 de repuestos en Chile</span>
          </div>

          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
            Encuentra los mejores{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-red-600">repuestos y talleres</span>{' '}
            cerca de ti
          </h1>

          <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
            Conectamos a los mejores proveedores de repuestos automotrices y talleres mecánicos con clientes de toda Chile.
          </p>

          <div className="max-w-2xl mx-auto mb-12">
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-red-600 to-red-800 rounded-2xl opacity-30 group-hover:opacity-50 transition-opacity blur" />
              <div className="relative flex items-center bg-[#111111] rounded-2xl border border-gray-700 overflow-hidden">
                <Search className="absolute left-4 w-5 h-5 text-gray-500" />
                <Input type="text" placeholder="¿Qué repuesto o servicio necesitas?" value={searchValue} onChange={(e) => setSearchValue(e.target.value)} className="flex-1 pl-12 pr-4 py-5 bg-transparent border-0 text-white" />
                <Button className="m-2 bg-red-600 hover:bg-red-700 text-white px-6">Buscar</Button>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-3">
            {categoriasDestacadas.map((categoria) => (
              <button key={categoria.id} onClick={() => onCategoriaClick(categoria.id)} className="group flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-red-500/20 border border-gray-700 hover:border-red-500/50 rounded-full transition-all">
                <span className="text-gray-300 group-hover:text-white text-sm">{categoria.nombre}</span>
                <ChevronRight className="w-4 h-4 text-gray-500 group-hover:text-red-400" />
              </button>
            ))}
          </div>

          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center"><div className="text-3xl md:text-4xl font-bold text-white mb-1">500+</div><div className="text-gray-500 text-sm">Negocios</div></div>
            <div className="text-center"><div className="text-3xl md:text-4xl font-bold text-white mb-1">50k+</div><div className="text-gray-500 text-sm">Productos</div></div>
            <div className="text-center"><div className="text-3xl md:text-4xl font-bold text-white mb-1">100k+</div><div className="text-gray-500 text-sm">Clientes</div></div>
            <div className="text-center"><div className="text-3xl md:text-4xl font-bold text-white mb-1">15+</div><div className="text-gray-500 text-sm">Ciudades</div></div>
          </div>
        </div>
      </div>
    </section>
  );
}
