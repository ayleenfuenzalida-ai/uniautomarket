import { ChevronRight, Settings, Wrench, Circle, Droplets, Zap, Wind, Cog, Activity } from 'lucide-react';
import type { Categoria } from '@/types';

interface CategoriesSectionProps {
  categorias: Categoria[];
  onCategoriaClick: (categoriaId: string) => void;
}

const iconMap: Record<string, React.ElementType> = { Settings, Wrench, Circle, Droplets, Zap, Wind, Cog, Activity };

export function CategoriesSection({ categorias, onCategoriaClick }: CategoriesSectionProps) {
  return (
    <section className="py-20 bg-[#0a0a0a]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Explora por <span className="text-red-500">categoría</span></h2>
          <p className="text-gray-400 max-w-2xl mx-auto">Encuentra exactamente lo que necesitas navegando por nuestras categorías especializadas</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {categorias.map((categoria) => {
            const IconComponent = iconMap[categoria.icono] || Settings;
            return (
              <button key={categoria.id} onClick={() => onCategoriaClick(categoria.id)} className="group relative overflow-hidden bg-[#111111] rounded-2xl p-6 border border-gray-800 hover:border-red-500/50 transition-all text-left">
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity" style={{ background: `radial-gradient(circle at 50% 0%, ${categoria.color}20, transparent 70%)` }} />
                <div className="relative">
                  <div className="w-14 h-14 rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110" style={{ backgroundColor: `${categoria.color}20` }}>
                    <IconComponent className="w-7 h-7" style={{ color: categoria.color }} />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-red-400 transition-colors">{categoria.nombre}</h3>
                  <p className="text-gray-500 text-sm mb-4">{categoria.descripcion}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600 text-sm">{categoria.negocios.length} negocios</span>
                    <ChevronRight className="w-5 h-5 text-gray-600 group-hover:text-red-500 transition-all" />
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
