import { initializeApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  deleteDoc,
  onSnapshot,
  Timestamp
} from 'firebase/firestore';
import type { Categoria, Negocio, Usuario, Pregunta, Respuesta } from '@/types';

const firebaseConfig = {
  apiKey: "AIzaSyCWPzLCFQbS6BOMnkT8R7AkfNm1I0r4cAI",
  authDomain: "uniautomarket-f6ffa.firebaseapp.com",
  projectId: "uniautomarket-f6ffa",
  storageBucket: "uniautomarket-f6ffa.firebasestorage.app",
  messagingSenderId: "419809946130",
  appId: "1:419809946130:web:b19c58f9203fb42b9d46cb"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const CATEGORIAS_COLLECTION = 'categorias';
const USUARIOS_COLLECTION = 'usuarios';
const PREGUNTAS_COLLECTION = 'preguntas';

export async function fetchCategoriasFromFirebase(): Promise<Categoria[]> {
  try {
    const categoriasRef = collection(db, CATEGORIAS_COLLECTION);
    const snapshot = await getDocs(categoriasRef);
    
    if (snapshot.empty) return [];
    
    const categorias: Categoria[] = [];
    snapshot.forEach((doc) => {
      const data = doc.data();
      categorias.push({
        id: doc.id,
        ...data,
        negocios: data.negocios || []
      } as Categoria);
    });
    
    return categorias.sort((a, b) => a.orden - b.orden);
  } catch (error) {
    console.error('Error fetching categorías:', error);
    throw error;
  }
}

export async function saveCategoriaToFirebase(categoria: Categoria): Promise<void> {
  try {
    const categoriaRef = doc(db, CATEGORIAS_COLLECTION, categoria.id);
    await setDoc(categoriaRef, {
      ...categoria,
      lastUpdated: Timestamp.now()
    });
  } catch (error) {
    console.error('Error saving categoría:', error);
    throw error;
  }
}

export async function updateCategoriaInFirebase(id: string, data: Partial<Categoria>): Promise<void> {
  try {
    const categoriaRef = doc(db, CATEGORIAS_COLLECTION, id);
    await updateDoc(categoriaRef, {
      ...data,
      lastUpdated: Timestamp.now()
    });
  } catch (error) {
    console.error('Error updating categoría:', error);
    throw error;
  }
}

export async function deleteCategoriaFromFirebase(id: string): Promise<void> {
  try {
    const categoriaRef = doc(db, CATEGORIAS_COLLECTION, id);
    await deleteDoc(categoriaRef);
  } catch (error) {
    console.error('Error deleting categoría:', error);
    throw error;
  }
}

export async function addNegocioToFirebase(categoriaId: string, negocio: Negocio): Promise<void> {
  try {
    const categoriaRef = doc(db, CATEGORIAS_COLLECTION, categoriaId);
    const categoriaSnap = await getDoc(categoriaRef);
    
    if (!categoriaSnap.exists()) throw new Error('Categoría no encontrada');
    
    const categoriaData = categoriaSnap.data() as Categoria;
    const negocios = categoriaData.negocios || [];
    
    const existingIndex = negocios.findIndex(n => n.id === negocio.id);
    if (existingIndex >= 0) {
      negocios[existingIndex] = negocio;
    } else {
      negocios.push(negocio);
    }
    
    await updateDoc(categoriaRef, {
      negocios,
      lastUpdated: Timestamp.now()
    });
  } catch (error) {
    console.error('Error adding negocio:', error);
    throw error;
  }
}

export async function updateNegocioInFirebase(categoriaId: string, negocioId: string, data: Partial<Negocio>): Promise<void> {
  try {
    const categoriaRef = doc(db, CATEGORIAS_COLLECTION, categoriaId);
    const categoriaSnap = await getDoc(categoriaRef);
    
    if (!categoriaSnap.exists()) throw new Error('Categoría no encontrada');
    
    const categoriaData = categoriaSnap.data() as Categoria;
    const negocios = categoriaData.negocios || [];
    
    const negocioIndex = negocios.findIndex(n => n.id === negocioId);
    if (negocioIndex === -1) throw new Error('Negocio no encontrado');
    
    negocios[negocioIndex] = { ...negocios[negocioIndex], ...data };
    
    await updateDoc(categoriaRef, {
      negocios,
      lastUpdated: Timestamp.now()
    });
  } catch (error) {
    console.error('Error updating negocio:', error);
    throw error;
  }
}

export async function deleteNegocioFromFirebase(categoriaId: string, negocioId: string): Promise<void> {
  try {
    const categoriaRef = doc(db, CATEGORIAS_COLLECTION, categoriaId);
    const categoriaSnap = await getDoc(categoriaRef);
    
    if (!categoriaSnap.exists()) throw new Error('Categoría no encontrada');
    
    const categoriaData = categoriaSnap.data() as Categoria;
    const negocios = (categoriaData.negocios || []).filter(n => n.id !== negocioId);
    
    await updateDoc(categoriaRef, {
      negocios,
      lastUpdated: Timestamp.now()
    });
  } catch (error) {
    console.error('Error deleting negocio:', error);
    throw error;
  }
}

export async function fetchUsuariosFromFirebase(): Promise<Usuario[]> {
  try {
    const usuariosRef = collection(db, USUARIOS_COLLECTION);
    const snapshot = await getDocs(usuariosRef);
    
    const usuarios: Usuario[] = [];
    snapshot.forEach((doc) => {
      usuarios.push({ id: doc.id, ...doc.data() } as Usuario);
    });
    
    return usuarios;
  } catch (error) {
    console.error('Error fetching usuarios:', error);
    throw error;
  }
}

export async function saveUsuarioToFirebase(usuario: Usuario): Promise<void> {
  try {
    const usuarioRef = doc(db, USUARIOS_COLLECTION, usuario.id);
    await setDoc(usuarioRef, usuario);
  } catch (error) {
    console.error('Error saving usuario:', error);
    throw error;
  }
}

export async function updateUsuarioInFirebase(id: string, data: Partial<Usuario>): Promise<void> {
  try {
    const usuarioRef = doc(db, USUARIOS_COLLECTION, id);
    await updateDoc(usuarioRef, data);
  } catch (error) {
    console.error('Error updating usuario:', error);
    throw error;
  }
}

export async function deleteUsuarioFromFirebase(id: string): Promise<void> {
  try {
    const usuarioRef = doc(db, USUARIOS_COLLECTION, id);
    await deleteDoc(usuarioRef);
  } catch (error) {
    console.error('Error deleting usuario:', error);
    throw error;
  }
}

export function subscribeToCategorias(callback: (categorias: Categoria[]) => void): () => void {
  const categoriasRef = collection(db, CATEGORIAS_COLLECTION);
  
  return onSnapshot(categoriasRef, (snapshot) => {
    const categorias: Categoria[] = [];
    snapshot.forEach((doc) => {
      const data = doc.data();
      categorias.push({
        id: doc.id,
        ...data,
        negocios: data.negocios || []
      } as Categoria);
    });
    
    callback(categorias.sort((a, b) => a.orden - b.orden));
  }, (error) => {
    console.error('Error en suscripción:', error);
  });
}

export function subscribeToUsuarios(callback: (usuarios: Usuario[]) => void): () => void {
  const usuariosRef = collection(db, USUARIOS_COLLECTION);
  
  return onSnapshot(usuariosRef, (snapshot) => {
    const usuarios: Usuario[] = [];
    snapshot.forEach((doc) => {
      usuarios.push({ id: doc.id, ...doc.data() } as Usuario);
    });
    
    callback(usuarios);
  }, (error) => {
    console.error('Error en suscripción de usuarios:', error);
  });
}

export async function initializeFirebaseData(): Promise<void> {
  try {
    const categoriasRef = collection(db, CATEGORIAS_COLLECTION);
    const snapshot = await getDocs(categoriasRef);
    
    if (snapshot.empty) {
      console.log('Firebase inicializado, listo para datos');
    }
  } catch (error) {
    console.error('Error initializing Firebase:', error);
    throw error;
  }
}

// Funciones para Preguntas del Blog
export async function fetchPreguntasFromFirebase(): Promise<Pregunta[]> {
  try {
    const preguntasRef = collection(db, PREGUNTAS_COLLECTION);
    const snapshot = await getDocs(preguntasRef);
    
    const preguntas: Pregunta[] = [];
    snapshot.forEach((doc) => {
      const data = doc.data();
      preguntas.push({
        id: doc.id,
        ...data,
        respuestas: data.respuestas || [],
        vistas: data.vistas || 0,
        resuelta: data.resuelta || false
      } as Pregunta);
    });
    
    return preguntas.sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime());
  } catch (error) {
    console.error('Error fetching preguntas:', error);
    throw error;
  }
}

export async function savePreguntaToFirebase(pregunta: Pregunta): Promise<void> {
  try {
    const preguntaRef = doc(db, PREGUNTAS_COLLECTION, pregunta.id);
    await setDoc(preguntaRef, {
      ...pregunta,
      lastUpdated: Timestamp.now()
    });
  } catch (error) {
    console.error('Error saving pregunta:', error);
    throw error;
  }
}

export async function updatePreguntaInFirebase(id: string, data: Partial<Pregunta>): Promise<void> {
  try {
    const preguntaRef = doc(db, PREGUNTAS_COLLECTION, id);
    await updateDoc(preguntaRef, {
      ...data,
      lastUpdated: Timestamp.now()
    });
  } catch (error) {
    console.error('Error updating pregunta:', error);
    throw error;
  }
}

export async function deletePreguntaFromFirebase(id: string): Promise<void> {
  try {
    const preguntaRef = doc(db, PREGUNTAS_COLLECTION, id);
    await deleteDoc(preguntaRef);
  } catch (error) {
    console.error('Error deleting pregunta:', error);
    throw error;
  }
}

export async function addRespuestaToFirebase(preguntaId: string, respuesta: Respuesta): Promise<void> {
  try {
    const preguntaRef = doc(db, PREGUNTAS_COLLECTION, preguntaId);
    const preguntaSnap = await getDoc(preguntaRef);
    
    if (!preguntaSnap.exists()) throw new Error('Pregunta no encontrada');
    
    const preguntaData = preguntaSnap.data() as Pregunta;
    const respuestas = preguntaData.respuestas || [];
    respuestas.push(respuesta);
    
    await updateDoc(preguntaRef, {
      respuestas,
      lastUpdated: Timestamp.now()
    });
  } catch (error) {
    console.error('Error adding respuesta:', error);
    throw error;
  }
}

export function subscribeToPreguntas(callback: (preguntas: Pregunta[]) => void): () => void {
  const preguntasRef = collection(db, PREGUNTAS_COLLECTION);
  
  return onSnapshot(preguntasRef, (snapshot) => {
    const preguntas: Pregunta[] = [];
    snapshot.forEach((doc) => {
      const data = doc.data();
      preguntas.push({
        id: doc.id,
        ...data,
        respuestas: data.respuestas || [],
        vistas: data.vistas || 0,
        resuelta: data.resuelta || false
      } as Pregunta);
    });
    
    callback(preguntas.sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime()));
  }, (error) => {
    console.error('Error en suscripción de preguntas:', error);
  });
}

export { db, app };
