import { useState, useEffect } from 'react';
import { Search, ChevronRight, ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useData } from '@/contexts/DataContext';

interface HeroSectionProps {
  onCategoriaClick: (categoriaId: string) => void;
}

const heroCars = [
  { image: '/images/hero/car1.jpg', title: 'Deportivos de Alto Rendimiento' },
  { image: '/images/hero/car2.jpg', title: '4x4 y Camionetas' },
  { image: '/images/hero/car3.jpg', title: 'Sedanes Elegantes' },
  { image: '/images/hero/car4.jpg', title: 'SUV Familiares' },
];

export function HeroSection({ onCategoriaClick }: HeroSectionProps) {
  const { categorias } = useData();
  const [searchValue, setSearchValue] = useState('');
  const [currentSlide, setCurrentSlide] = useState(0);
  const categoriasDestacadas = categorias.filter(c => c.destacada).slice(0, 4);

  // Auto-rotate carousel
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroCars.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % heroCars.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + heroCars.length) % heroCars.length);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Carousel */}
      <div className="absolute inset-0">
        {heroCars.map((car, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <img
              src={car.image}
              alt={car.title}
              className="w-full h-full object-cover object-center scale-110"
            />
          </div>
        ))}
        {/* Dark overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/60 to-[#0a0a0a]/40" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a]/80 via-transparent to-[#0a0a0a]/80" />
      </div>

      {/* Carousel Controls */}
      <button
        onClick={prevSlide}
        className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-full bg-black/50 backdrop-blur-sm border border-white/20 flex items-center justify-center text-white hover:bg-red-600/80 transition-all"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-full bg-black/50 backdrop-blur-sm border border-white/20 flex items-center justify-center text-white hover:bg-red-600/80 transition-all"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Slide Indicators */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex gap-2">
        {heroCars.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-all ${
              index === currentSlide ? 'bg-red-500 w-8' : 'bg-white/50 hover:bg-white/80'
            }`}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-500/20 border border-red-500/30 rounded-full mb-8 backdrop-blur-sm">
            <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
            <span className="text-red-400 text-sm font-medium">El marketplace #1 de repuestos en Chile</span>
          </div>

          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-6 leading-tight drop-shadow-2xl">
            Encuentra los mejores{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-red-600">
              repuestos y talleres
            </span>{' '}
            cerca de ti
          </h1>

          <p className="text-xl md:text-2xl text-gray-200 mb-10 max-w-2xl mx-auto drop-shadow-lg">
            Conectamos a los mejores proveedores de repuestos automotrices y talleres mecánicos con clientes de toda Chile.
          </p>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto mb-12">
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-red-600 to-red-800 rounded-2xl opacity-30 group-hover:opacity-50 transition-opacity blur" />
              <div className="relative flex items-center bg-[#111111]/90 backdrop-blur-xl rounded-2xl border border-gray-700 overflow-hidden">
                <Search className="absolute left-4 w-5 h-5 text-gray-500" />
                <Input
                  type="text"
                  placeholder="¿Qué repuesto o servicio necesitas?"
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                  className="flex-1 pl-12 pr-4 py-6 bg-transparent border-0 text-white text-lg"
                />
                <Button className="m-2 bg-red-600 hover:bg-red-700 text-white px-8 py-6 text-lg">
                  Buscar
                </Button>
              </div>
            </div>
          </div>

          {/* Quick Categories */}
          <div className="flex flex-wrap justify-center gap-3 mb-16">
            {categoriasDestacadas.map((categoria) => (
              <button
                key={categoria.id}
                onClick={() => onCategoriaClick(categoria.id)}
                className="group flex items-center gap-2 px-5 py-3 bg-black/50 backdrop-blur-sm hover:bg-red-500/30 border border-gray-700 hover:border-red-500/50 rounded-full transition-all"
              >
                <span className="text-white group-hover:text-white text-sm font-medium">{categoria.nombre}</span>
                <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-red-400" />
              </button>
            ))}
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-white mb-1">500+</div>
              <div className="text-gray-400 text-sm">Negocios</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-white mb-1">50k+</div>
              <div className="text-gray-400 text-sm">Productos</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-white mb-1">100k+</div>
              <div className="text-gray-400 text-sm">Clientes</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-white mb-1">15+</div>
              <div className="text-gray-400 text-sm">Ciudades</div>
            </div>
          </div>
        </div>
      </div>

      {/* Current Slide Title */}
      <div className="absolute bottom-24 left-8 z-20 hidden md:block">
        <p className="text-white/60 text-sm mb-1">Destacado</p>
        <p className="text-white text-xl font-semibold">{heroCars[currentSlide].title}</p>
      </div>
    </section>
  );
}
