import { ChevronRight } from 'lucide-react';
import type { Categoria } from '@/types';

interface CategoriesSectionProps {
  categorias: Categoria[];
  onCategoriaClick: (categoriaId: string) => void;
}

export function CategoriesSection({ categorias, onCategoriaClick }: CategoriesSectionProps) {
  return (
    <section className="py-20 bg-[#0a0a0a]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Explora por <span className="text-red-500">categoría</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Encuentra exactamente lo que necesitas navegando por nuestras categorías especializadas
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {categorias.map((categoria) => (
            <button
              key={categoria.id}
              onClick={() => onCategoriaClick(categoria.id)}
              className="group relative overflow-hidden rounded-2xl border border-gray-800 hover:border-red-500/50 transition-all text-left h-[280px]"
            >
              {/* Background Image */}
              <div className="absolute inset-0">
                <img
                  src={categoria.imagen}
                  alt={categoria.nombre}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                {/* Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent" />
              </div>

              {/* Content */}
              <div className="relative h-full flex flex-col justify-end p-6">
                {/* Color accent bar */}
                <div
                  className="absolute top-0 left-0 w-full h-1 transition-all duration-300 group-hover:h-2"
                  style={{ backgroundColor: categoria.color }}
                />

                <div className="transform transition-transform duration-300 group-hover:-translate-y-2">
                  <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-red-400 transition-colors">
                    {categoria.nombre}
                  </h3>
                  <p className="text-gray-300 text-sm mb-4 line-clamp-2">
                    {categoria.descripcion}
                  </p>

                  <div className="flex items-center justify-between">
                    <span className="text-white/80 text-sm font-medium bg-black/50 px-3 py-1 rounded-full backdrop-blur-sm">
                      {categoria.negocios.length} negocios
                    </span>
                    <div className="w-10 h-10 rounded-full bg-red-600 flex items-center justify-center transform transition-all duration-300 group-hover:scale-110 group-hover:bg-red-500">
                      <ChevronRight className="w-5 h-5 text-white" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Hover glow effect */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
                style={{
                  background: `radial-gradient(circle at 50% 100%, ${categoria.color}30, transparent 70%)`
                }}
              />
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
