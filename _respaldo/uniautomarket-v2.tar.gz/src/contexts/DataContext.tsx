import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { Categoria, Negocio, Producto, Servicio, Resena, Chat, MensajeChat } from '@/types';
import {
  fetchCategoriasFromFirebase,
  saveCategoriaToFirebase,
  updateCategoriaInFirebase,
  deleteCategoriaFromFirebase,
  addNegocioToFirebase,
  updateNegocioInFirebase,
  deleteNegocioFromFirebase,
  subscribeToCategorias,
  initializeFirebaseData
} from '@/utils/firebase';
import type { DataContextType } from '@/types';

const DataContext = createContext<DataContextType | undefined>(undefined);

const categoriasIniciales: Omit<Categoria, 'id' | 'negocios'>[] = [
  { nombre: 'Desarmadurías', descripcion: 'Encuentra repuestos usados y piezas de desarme', icono: 'Settings', imagen: 'https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=800&q=80', color: '#EF4444', destacada: true, orden: 1 },
  { nombre: 'Talleres Mecánicos', descripcion: 'Servicio técnico especializado para tu vehículo', icono: 'Wrench', imagen: 'https://images.unsplash.com/photo-1632823471565-1ecdf5c6d8c3?w=800&q=80', color: '#F97316', destacada: true, orden: 2 },
  { nombre: 'Repuestos', descripcion: 'Repuestos originales y alternativos nuevos', icono: 'Package', imagen: 'https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=800&q=80', color: '#22C55E', destacada: true, orden: 3 },
  { nombre: 'Herramientas', descripcion: 'Herramientas especializadas para mecánica', icono: 'Tool', imagen: 'https://images.unsplash.com/photo-1581147036324-c17ac41dfa6c?w=800&q=80', color: '#3B82F6', destacada: true, orden: 4 },
  { nombre: 'Pintura y Desabolladura', descripcion: 'Reparación de carrocería y pintura automotriz', icono: 'Paintbrush', imagen: 'https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?w=800&q=80', color: '#EAB308', destacada: true, orden: 5 },
  { nombre: 'Electrónica', descripcion: 'Diagnóstico y reparación de sistemas electrónicos', icono: 'Cpu', imagen: 'https://images.unsplash.com/photo-1625047509168-a7026f36de04?w=800&q=80', color: '#8B5CF6', destacada: true, orden: 6 }
];

export function DataProvider({ children }: { children: React.ReactNode }) {
  const [categorias, setCategorias] = useState<Categoria[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    const init = async () => {
      try {
        await initializeFirebaseData();
        const cats = await fetchCategoriasFromFirebase();
        
        if (cats.length === 0) {
          const nuevasCategorias = await crearCategoriasIniciales();
          setCategorias(nuevasCategorias);
        } else {
          setCategorias(cats);
        }
        
        setInitialized(true);
      } catch (err) {
        console.error('Error inicializando:', err);
        setError('Error al cargar datos');
      } finally {
        setLoading(false);
      }
    };
    
    init();
  }, []);

  useEffect(() => {
    if (!initialized) return;
    const unsubscribe = subscribeToCategorias((updatedCategorias) => {
      setCategorias(updatedCategorias);
    });
    return () => unsubscribe();
  }, [initialized]);

  const crearCategoriasIniciales = async (): Promise<Categoria[]> => {
    const nuevasCategorias: Categoria[] = [];
    
    for (const cat of categoriasIniciales) {
      const id = cat.nombre.toLowerCase().replace(/\s+/g, '-');
      const nuevaCategoria: Categoria = { ...cat, id, negocios: [] };
      await saveCategoriaToFirebase(nuevaCategoria);
      nuevasCategorias.push(nuevaCategoria);
    }
    
    return nuevasCategorias;
  };

  const addCategoria = useCallback(async (categoria: Omit<Categoria, 'id' | 'negocios'>) => {
    const id = categoria.nombre.toLowerCase().replace(/\s+/g, '-');
    const nuevaCategoria: Categoria = { ...categoria, id, negocios: [] };
    await saveCategoriaToFirebase(nuevaCategoria);
    setCategorias(prev => [...prev, nuevaCategoria].sort((a, b) => a.orden - b.orden));
  }, []);

  const updateCategoria = useCallback(async (id: string, data: Partial<Categoria>) => {
    await updateCategoriaInFirebase(id, data);
    setCategorias(prev => prev.map(cat => cat.id === id ? { ...cat, ...data } : cat));
  }, []);

  const deleteCategoria = useCallback(async (id: string) => {
    await deleteCategoriaFromFirebase(id);
    setCategorias(prev => prev.filter(cat => cat.id !== id));
  }, []);

  const addNegocio = useCallback(async (categoriaId: string, negocio: Omit<Negocio, 'id' | 'fechaRegistro' | 'visitas' | 'chats'>) => {
    const nuevoNegocio: Negocio = {
      ...negocio,
      id: `negocio-${Date.now()}`,
      fechaRegistro: new Date().toISOString(),
      visitas: 0,
      chats: []
    };
    
    await addNegocioToFirebase(categoriaId, nuevoNegocio);
    
    setCategorias(prev => prev.map(cat => {
      if (cat.id === categoriaId) {
        return { ...cat, negocios: [...cat.negocios, nuevoNegocio] };
      }
      return cat;
    }));
  }, []);

  const updateNegocio = useCallback(async (categoriaId: string, negocioId: string, data: Partial<Negocio>) => {
    await updateNegocioInFirebase(categoriaId, negocioId, data);
    setCategorias(prev => prev.map(cat => {
      if (cat.id === categoriaId) {
        return {
          ...cat,
          negocios: cat.negocios.map(neg => neg.id === negocioId ? { ...neg, ...data } : neg)
        };
      }
      return cat;
    }));
  }, []);

  const deleteNegocio = useCallback(async (categoriaId: string, negocioId: string) => {
    await deleteNegocioFromFirebase(categoriaId, negocioId);
    setCategorias(prev => prev.map(cat => {
      if (cat.id === categoriaId) {
        return { ...cat, negocios: cat.negocios.filter(neg => neg.id !== negocioId) };
      }
      return cat;
    }));
  }, []);

  const getNegocioById = useCallback((negocioId: string): Negocio | undefined => {
    for (const categoria of categorias) {
      const negocio = categoria.negocios.find(n => n.id === negocioId);
      if (negocio) return negocio;
    }
    return undefined;
  }, [categorias]);

  const getCategoriaByNegocioId = useCallback((negocioId: string): Categoria | undefined => {
    return categorias.find(cat => cat.negocios.some(n => n.id === negocioId));
  }, [categorias]);

  const incrementarVisitas = useCallback(async (negocioId: string) => {
    const categoria = getCategoriaByNegocioId(negocioId);
    if (!categoria) return;
    const negocio = getNegocioById(negocioId);
    if (!negocio) return;
    await updateNegocioInFirebase(categoria.id, negocioId, { visitas: (negocio.visitas || 0) + 1 });
  }, [getCategoriaByNegocioId, getNegocioById]);

  const addProducto = useCallback(async (categoriaId: string, negocioId: string, producto: Omit<Producto, 'id'>) => {
    const nuevoProducto: Producto = { ...producto, id: `producto-${Date.now()}` };
    const categoria = categorias.find(c => c.id === categoriaId);
    if (!categoria) throw new Error('Categoría no encontrada');
    const negocio = categoria.negocios.find(n => n.id === negocioId);
    if (!negocio) throw new Error('Negocio no encontrado');
    
    const productosActualizados = [...negocio.productos, nuevoProducto];
    await updateNegocioInFirebase(categoriaId, negocioId, { productos: productosActualizados });
    
    setCategorias(prev => prev.map(cat => {
      if (cat.id === categoriaId) {
        return {
          ...cat,
          negocios: cat.negocios.map(neg => neg.id === negocioId ? { ...neg, productos: productosActualizados } : neg)
        };
      }
      return cat;
    }));
  }, [categorias]);

  const updateProducto = useCallback(async (categoriaId: string, negocioId: string, productoId: string, data: Partial<Producto>) => {
    const categoria = categorias.find(c => c.id === categoriaId);
    if (!categoria) throw new Error('Categoría no encontrada');
    const negocio = categoria.negocios.find(n => n.id === negocioId);
    if (!negocio) throw new Error('Negocio no encontrado');
    
    const productosActualizados = negocio.productos.map(p => p.id === productoId ? { ...p, ...data } : p);
    await updateNegocioInFirebase(categoriaId, negocioId, { productos: productosActualizados });
    
    setCategorias(prev => prev.map(cat => {
      if (cat.id === categoriaId) {
        return {
          ...cat,
          negocios: cat.negocios.map(neg => neg.id === negocioId ? { ...neg, productos: productosActualizados } : neg)
        };
      }
      return cat;
    }));
  }, [categorias]);

  const deleteProducto = useCallback(async (categoriaId: string, negocioId: string, productoId: string) => {
    const categoria = categorias.find(c => c.id === categoriaId);
    if (!categoria) throw new Error('Categoría no encontrada');
    const negocio = categoria.negocios.find(n => n.id === negocioId);
    if (!negocio) throw new Error('Negocio no encontrado');
    
    const productosActualizados = negocio.productos.filter(p => p.id !== productoId);
    await updateNegocioInFirebase(categoriaId, negocioId, { productos: productosActualizados });
    
    setCategorias(prev => prev.map(cat => {
      if (cat.id === categoriaId) {
        return {
          ...cat,
          negocios: cat.negocios.map(neg => neg.id === negocioId ? { ...neg, productos: productosActualizados } : neg)
        };
      }
      return cat;
    }));
  }, [categorias]);

  const addServicio = useCallback(async (categoriaId: string, negocioId: string, servicio: Omit<Servicio, 'id'>) => {
    const nuevoServicio: Servicio = { ...servicio, id: `servicio-${Date.now()}` };
    const categoria = categorias.find(c => c.id === categoriaId);
    if (!categoria) throw new Error('Categoría no encontrada');
    const negocio = categoria.negocios.find(n => n.id === negocioId);
    if (!negocio) throw new Error('Negocio no encontrado');
    
    const serviciosActualizados = [...negocio.servicios, nuevoServicio];
    await updateNegocioInFirebase(categoriaId, negocioId, { servicios: serviciosActualizados });
    
    setCategorias(prev => prev.map(cat => {
      if (cat.id === categoriaId) {
        return {
          ...cat,
          negocios: cat.negocios.map(neg => neg.id === negocioId ? { ...neg, servicios: serviciosActualizados } : neg)
        };
      }
      return cat;
    }));
  }, [categorias]);

  const updateServicio = useCallback(async (categoriaId: string, negocioId: string, servicioId: string, data: Partial<Servicio>) => {
    const categoria = categorias.find(c => c.id === categoriaId);
    if (!categoria) throw new Error('Categoría no encontrada');
    const negocio = categoria.negocios.find(n => n.id === negocioId);
    if (!negocio) throw new Error('Negocio no encontrado');
    
    const serviciosActualizados = negocio.servicios.map(s => s.id === servicioId ? { ...s, ...data } : s);
    await updateNegocioInFirebase(categoriaId, negocioId, { servicios: serviciosActualizados });
    
    setCategorias(prev => prev.map(cat => {
      if (cat.id === categoriaId) {
        return {
          ...cat,
          negocios: cat.negocios.map(neg => neg.id === negocioId ? { ...neg, servicios: serviciosActualizados } : neg)
        };
      }
      return cat;
    }));
  }, [categorias]);

  const deleteServicio = useCallback(async (categoriaId: string, negocioId: string, servicioId: string) => {
    const categoria = categorias.find(c => c.id === categoriaId);
    if (!categoria) throw new Error('Categoría no encontrada');
    const negocio = categoria.negocios.find(n => n.id === negocioId);
    if (!negocio) throw new Error('Negocio no encontrado');
    
    const serviciosActualizados = negocio.servicios.filter(s => s.id !== servicioId);
    await updateNegocioInFirebase(categoriaId, negocioId, { servicios: serviciosActualizados });
    
    setCategorias(prev => prev.map(cat => {
      if (cat.id === categoriaId) {
        return {
          ...cat,
          negocios: cat.negocios.map(neg => neg.id === negocioId ? { ...neg, servicios: serviciosActualizados } : neg)
        };
      }
      return cat;
    }));
  }, [categorias]);

  const addResena = useCallback(async (categoriaId: string, negocioId: string, resena: Omit<Resena, 'id'>) => {
    const nuevaResena: Resena = { ...resena, id: `resena-${Date.now()}` };
    const categoria = categorias.find(c => c.id === categoriaId);
    if (!categoria) throw new Error('Categoría no encontrada');
    const negocio = categoria.negocios.find(n => n.id === negocioId);
    if (!negocio) throw new Error('Negocio no encontrado');
    
    const resenasActualizadas = [...negocio.resenas, nuevaResena];
    await updateNegocioInFirebase(categoriaId, negocioId, { resenas: resenasActualizadas });
    
    setCategorias(prev => prev.map(cat => {
      if (cat.id === categoriaId) {
        return {
          ...cat,
          negocios: cat.negocios.map(neg => neg.id === negocioId ? { ...neg, resenas: resenasActualizadas } : neg)
        };
      }
      return cat;
    }));
  }, [categorias]);

  const addChat = useCallback(async (categoriaId: string, negocioId: string, chat: Omit<Chat, 'id' | 'ultimaActualizacion'>) => {
    const nuevoChat: Chat = { ...chat, id: `chat-${Date.now()}`, ultimaActualizacion: new Date().toISOString() };
    const categoria = categorias.find(c => c.id === categoriaId);
    if (!categoria) throw new Error('Categoría no encontrada');
    const negocio = categoria.negocios.find(n => n.id === negocioId);
    if (!negocio) throw new Error('Negocio no encontrado');
    
    const chatsActualizados = [...negocio.chats, nuevoChat];
    await updateNegocioInFirebase(categoriaId, negocioId, { chats: chatsActualizados });
    
    setCategorias(prev => prev.map(cat => {
      if (cat.id === categoriaId) {
        return {
          ...cat,
          negocios: cat.negocios.map(neg => neg.id === negocioId ? { ...neg, chats: chatsActualizados } : neg)
        };
      }
      return cat;
    }));
  }, [categorias]);

  const addMensajeToChat = useCallback(async (categoriaId: string, negocioId: string, chatId: string, mensaje: Omit<MensajeChat, 'id'>) => {
    const nuevoMensaje: MensajeChat = { ...mensaje, id: `mensaje-${Date.now()}` };
    const categoria = categorias.find(c => c.id === categoriaId);
    if (!categoria) throw new Error('Categoría no encontrada');
    const negocio = categoria.negocios.find(n => n.id === negocioId);
    if (!negocio) throw new Error('Negocio no encontrado');
    
    const chatsActualizados = negocio.chats.map(chat => {
      if (chat.id === chatId) {
        return { ...chat, mensajes: [...chat.mensajes, nuevoMensaje], ultimaActualizacion: new Date().toISOString() };
      }
      return chat;
    });
    
    await updateNegocioInFirebase(categoriaId, negocioId, { chats: chatsActualizados });
    
    setCategorias(prev => prev.map(cat => {
      if (cat.id === categoriaId) {
        return {
          ...cat,
          negocios: cat.negocios.map(neg => neg.id === negocioId ? { ...neg, chats: chatsActualizados } : neg)
        };
      }
      return cat;
    }));
  }, [categorias]);

  const marcarMensajesLeidos = useCallback(async (categoriaId: string, negocioId: string, chatId: string, usuarioId: string) => {
    const categoria = categorias.find(c => c.id === categoriaId);
    if (!categoria) throw new Error('Categoría no encontrada');
    const negocio = categoria.negocios.find(n => n.id === negocioId);
    if (!negocio) throw new Error('Negocio no encontrado');
    
    const chatsActualizados = negocio.chats.map(chat => {
      if (chat.id === chatId) {
        return { ...chat, mensajes: chat.mensajes.map(m => m.autorId !== usuarioId ? { ...m, leido: true } : m) };
      }
      return chat;
    });
    
    await updateNegocioInFirebase(categoriaId, negocioId, { chats: chatsActualizados });
    
    setCategorias(prev => prev.map(cat => {
      if (cat.id === categoriaId) {
        return {
          ...cat,
          negocios: cat.negocios.map(neg => neg.id === negocioId ? { ...neg, chats: chatsActualizados } : neg)
        };
      }
      return cat;
    }));
  }, [categorias]);

  const searchNegocios = useCallback((query: string): Array<{ negocio: Negocio; categoria: Categoria }> => {
    const results: Array<{ negocio: Negocio; categoria: Categoria }> = [];
    const lowerQuery = query.toLowerCase();
    
    for (const categoria of categorias) {
      for (const negocio of categoria.negocios) {
        if (
          negocio.nombre.toLowerCase().includes(lowerQuery) ||
          negocio.descripcion.toLowerCase().includes(lowerQuery) ||
          negocio.direccion.toLowerCase().includes(lowerQuery) ||
          negocio.comuna.toLowerCase().includes(lowerQuery)
        ) {
          results.push({ negocio, categoria });
        }
      }
    }
    
    return results;
  }, [categorias]);

  const searchProductos = useCallback((query: string): Array<{ producto: Producto; negocio: Negocio; categoria: Categoria }> => {
    const results: Array<{ producto: Producto; negocio: Negocio; categoria: Categoria }> = [];
    const lowerQuery = query.toLowerCase();
    
    for (const categoria of categorias) {
      for (const negocio of categoria.negocios) {
        for (const producto of negocio.productos) {
          if (
            producto.nombre.toLowerCase().includes(lowerQuery) ||
            producto.descripcion.toLowerCase().includes(lowerQuery) ||
            producto.sku.toLowerCase().includes(lowerQuery)
          ) {
            results.push({ producto, negocio, categoria });
          }
        }
      }
    }
    
    return results;
  }, [categorias]);

  return (
    <DataContext.Provider value={{
      categorias, loading, error,
      addCategoria, updateCategoria, deleteCategoria,
      addNegocio, updateNegocio, deleteNegocio, getNegocioById, getCategoriaByNegocioId, incrementarVisitas,
      addProducto, updateProducto, deleteProducto,
      addServicio, updateServicio, deleteServicio,
      addResena, addChat, addMensajeToChat, marcarMensajesLeidos,
      searchNegocios, searchProductos
    }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) throw new Error('useData debe usarse dentro de DataProvider');
  return context;
}
