import { MapPin, Phone, Mail, Facebook, Instagram, Twitter } from 'lucide-react';
import { useCompany } from '@/contexts/CompanyContext';

interface FooterProps {
  onNavigateHome: () => void;
}

export function Footer({ onNavigateHome }: FooterProps) {
  const { empresaInfo } = useCompany();

  return (
    <footer className="bg-[#0a0a0a] border-t border-gray-800">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="h-10 w-10 bg-gradient-to-br from-red-500 to-red-700 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">U</span>
              </div>
              <span className="text-white font-bold text-lg">{empresaInfo.nombre}</span>
            </div>
            <p className="text-gray-400 text-sm mb-4">El marketplace #1 de repuestos y servicios automotrices en Chile.</p>
            <div className="flex gap-3">
              <a href={empresaInfo.redesSociales.facebook} target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center text-gray-400 hover:bg-red-500 hover:text-white transition-colors"><Facebook className="w-5 h-5" /></a>
              <a href={empresaInfo.redesSociales.instagram} target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center text-gray-400 hover:bg-red-500 hover:text-white transition-colors"><Instagram className="w-5 h-5" /></a>
              <a href={empresaInfo.redesSociales.twitter} target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center text-gray-400 hover:bg-red-500 hover:text-white transition-colors"><Twitter className="w-5 h-5" /></a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Contacto</h4>
            <div className="space-y-3">
              <div className="flex items-start gap-3 text-gray-400 text-sm"><MapPin className="w-5 h-5 text-red-500 flex-shrink-0" /><span>{empresaInfo.direccion}</span></div>
              <div className="flex items-center gap-3 text-gray-400 text-sm"><Phone className="w-5 h-5 text-red-500" /><span>{empresaInfo.telefono}</span></div>
              <div className="flex items-center gap-3 text-gray-400 text-sm"><Mail className="w-5 h-5 text-red-500" /><span>{empresaInfo.email}</span></div>
            </div>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Horario</h4>
            <p className="text-gray-400 text-sm">{empresaInfo.horarioAtencion}</p>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Enlaces</h4>
            <ul className="space-y-2">
              <li><button onClick={onNavigateHome} className="text-gray-400 hover:text-red-400 text-sm transition-colors">Inicio</button></li>
              <li><button className="text-gray-400 hover:text-red-400 text-sm transition-colors">Términos y condiciones</button></li>
              <li><button className="text-gray-400 hover:text-red-400 text-sm transition-colors">Política de privacidad</button></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center">
          <p className="text-gray-500 text-sm">© 2024 {empresaInfo.nombre}. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
